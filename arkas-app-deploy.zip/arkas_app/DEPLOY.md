# 🚀 Panduan Deploy ARKAS 2026 — SMP Negeri 7 Sentani

Aplikasi ini **self-contained**: seluruh data master sudah ada di folder `data/`,
backend memakai pustaka standar Python (`http.server`) + `openpyxl` (export Excel),
dan semua URL frontend bersifat **relatif** sehingga aman dijalankan di domain,
subdomain, maupun sub-path (dibalik reverse proxy).

Struktur siap deploy:

```
arkas_app/
├── server.py          # Backend (routing, API, export Excel)
├── requirements.txt   # Dependensi: openpyxl
├── start.sh           # Skrip start cepat
├── Dockerfile         # Image produksi
├── .dockerignore
├── data/
│   ├── arkas_data.json     # Data master 12 bulan (hasil ekstraksi PDF)
│   ├── arkas_meta.json     # Identitas sekolah, rekening, tanda tangan
│   └── arkas_userdata.json # Dibuat otomatis: revisi/realisasi/SPJ/ttd
├── deploy/
│   ├── arkas.service  # systemd (VPS)
│   ├── nginx.conf     # Reverse proxy + HTTPS
│   └── render.yaml    # Blueprint Render.com
└── static/
    ├── index.html / style.css / app.js
```

Variabel environment yang didukung:

| Variable          | Default               | Keteratan                                          |
| ----------------- | --------------------- | -------------------------------------------------- |
| `PORT`            | `8000`                | Port HTTP yang didengarkan (0.0.0.0)               |
| `ARKAS_DATA_DIR`  | `./data` (relatif app)| Lokasi folder data (untuk volume persisten)        |

---

## Opsi A — Docker (paling mudah, berlaku di mana saja)

```bash
cd arkas_app
docker build -t arkas-2026 .
docker run -d --name arkas -p 8000:8000 \
  -v arkas_data:/app/data \
  arkas-2026
# buka http://localhost:8000  (cek: /healthz)
```

## Opsi B — Render.com (gratis, tanpa VPS)

1. Push folder ini ke GitHub.
2. Render Dashboard → **New → Blueprint** → pilih repo → Render membaca `deploy/render.yaml`.
3. Tambahkan **Persistent Disk** mount path `/app/data` (agar data revisi/SPJ tersimpan).
4. Dapat URL publik `https://arkas-2026.onrender.com` — langsung bisa dibagikan.

## Opsi C — VPS (Ubuntu/Debian) + systemd + Nginx

```bash
# 1) Salin aplikasi
sudo mkdir -p /opt/arkas_app && sudo cp -r . /opt/arkas_app
sudo chown -R www-data:www-data /opt/arkas_app

# 2) Pasang dependensi
sudo apt update && sudo apt install -y python3 python3-pip
sudo -H pip3 install openpyxl

# 3) Pasang service systemd
sudo cp deploy/arkas.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now arkas
sudo systemctl status arkas          # harus: active (running)

# 4) Pasang Nginx + HTTPS
sudo apt install -y nginx
sudo cp deploy/nginx.conf /etc/nginx/sites-available/arkas
sudo ln -s /etc/nginx/sites-available/arkas /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# 5) (Opsional) SSL gratis dari Let's Encrypt
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d domain-anda.com
```

## Opsi D — Jalankan lokal (tanpa deploy)

```bash
cd arkas_app
pip install -r requirements.txt
python3 server.py          # atau: bash start.sh
# buka http://localhost:8000
```

---

## Cek kesehatan

```bash
curl http://localhost:8000/healthz
# {"ok": true, "app": "ARKAS 2026 SMPN 7 Sentani"}
```

## Catatan produksi

- Aplikasi ini **single-file state** (`data/arkas_userdata.json`): revisi/realisasi/SPJ/
  tanda tangan tersimpan di sana. Pastikan folder `data/` **persisten & dapat ditulis**
  oleh user yang menjalankan server (mount volume bila pakai container/PaaS).
- Untuk dipakai banyak sekolah, cukup jalankan satu instance per sekolah dengan
  `ARKAS_DATA_DIR` berbeda, atau duplikat folder aplikasi + ganti `arkas_meta.json`
  dan `arkas_data.json`.
