# ARKAS 2026 — SMP Negeri 7 Sentani

Aplikasi web ARKAS (Aplikasi Rencana Kegiatan dan Anggaran Sekolah) + **ARKAS PERUBAHAN**
untuk Tahun Anggaran 2026, sumber dana **BOSP Reguler**.

## Cara menjalankan

```bash
cd /home/user/arkas_app
python3 server.py        # lalu buka http://localhost:8000
```

Server memakai pustaka standar Python (`http.server`) + `openpyxl` untuk export Excel.

## Struktur

```
arkas_app/
├── server.py          # Backend: halaman, API /api/data & /api/save, export .xlsx
└── static/
    ├── index.html     # SPA (data di-inject sebagai window.__ARKAS__)
    ├── style.css      # Tampilan
    └── app.js         # Logika front-end
```

Data master (hasil ekstraksi PDF) disimpan di `data/arkas_data.json` dan
metadata sekolah di `data/arkas_meta.json`.
Data perubahan/realisasi tersimpan di `data/arkas_userdata.json` (dibuat otomatis).

## Fitur

1. **Dashboard** — ringkasan penerimaan, anggaran, realisasi, sisa, grafik serapan
   per bulan, rekap belanja per Standar Nasional Pendidikan, dan **grafik tren per Standar**
   (pilih standar → tren anggaran bulanan Jan–Des 2026).
2. **RKAS 2026** — dua tampilan:
   - *RKAS Tahunan (Format Resmi)* — formulir ARKAS resmi: judul "RENCANA KEGIATAN DAN
     ANGGARAN SEKOLAH (RKAS)", identitas (Nama Sekolah, Desa/Kecamatan, Kabupaten/Kota,
     Provinsi, Sumber Dana), tabel Penerimaan (Pagu Awal BOS, Sisa Dana BOS, Jasa/Bunga
     Bank, Diterima per Triwulan), info Bank (Nama Bank, No. Rekening, Atas Nama), serta
     tabel Belanja dengan kolom No. Urut, Kode Rekening, Belanja/Output(SNP)/Komponen/
     Kegiatan/Detil Biaya, Rincian Perhitungan, Volume, Satuan, Tarif Satuan, Jumlah dan
     rincian **Triwulan I–IV** (diagregasi otomatis dari data bulanan). Data sekolah &
     rekening bisa diedit dan disimpan.
   - *Kertas Kerja per Bulan* — rincian per bulan sesuai PDF, dengan **blok tanda tangan
     digital** dan tampilan cetak mirip formulir asli.
3. **ARKAS Perubahan**
   - *Revisi / Pergeseran* — ubah uraian/volume/satuan/tarif/jumlah, tambah/hapus item,
     hapus kelompok, bandingkan Sebelum vs Sesudah, simpan.
   - *Realisasi* — catat realisasi penyerapan per item, lihat % serapan, simpan.
4. **Catatan SPJ** — catat nomor SPJ, tanggal, uraian, nilai, dan bukti pengeluaran
   per bulan; tersimpan otomatis.
5. **Laporan & Export** — unduh Excel: `RKAS Resmi` (format resmi tahunan + triwulan),
   `RKAS 2026` (12 bulan + rekap), `ARKAS Perubahan` (sebelum vs sesudah), `Realisasi`,
   dan `Catatan SPJ`. Plus **manajemen tanda tangan digital** (gambar/bubuhkan tanda
   tangan di kanvas, isi nama & NIP, simpan).

## Ekstraksi PDF

`/home/user/extract.py` mem-parsing `uploads/ARKAS Januari-Desember  2026.pdf`
(34 halaman) menjadi `arkas_data.json`. Validasi: jumlah seluruh item daun per bulan
sama persis dengan total PDF (Jan 43.405.000 s.d. Des 17.320.000, total Rp 340.000.000).
