#!/usr/bin/env bash
# ARKAS 2026 — skrip start sederhana (lokal / VPS / container)
set -euo pipefail
cd "$(dirname "$0")"

PORT="${PORT:-8000}"
export ARKAS_DATA_DIR="${ARKAS_DATA_DIR:-$PWD/data}"

echo "ARKAS 2026 — SMP Negeri 7 Sentani"
echo "Mendengarkan di 0.0.0.0:${PORT}  (data: ${ARKAS_DATA_DIR})"
exec python3 server.py
