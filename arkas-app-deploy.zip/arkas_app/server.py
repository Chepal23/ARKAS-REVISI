# -*- coding: utf-8 -*-
"""
ARKAS 2026 - Aplikasi Rencana Kegiatan & Anggaran Sekolah + ARKAS PERUBAHAN
Server: stdlib http.server (tanpa dependensi web) + openpyxl untuk export Excel.
"""
import json
import os
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

BASE = os.path.dirname(os.path.abspath(__file__))
STATIC = os.path.join(BASE, 'static')
# Data master tinggal di dalam folder aplikasi (data/) sehingga self-contained.
# Bisa di-override lewat env ARKAS_DATA_DIR (mis. volume Docker agar data persisten).
DATA_DIR = os.environ.get('ARKAS_DATA_DIR', os.path.join(BASE, 'data'))
os.makedirs(DATA_DIR, exist_ok=True)
DATA_FILE = os.path.join(DATA_DIR, 'arkas_data.json')
META_FILE = os.path.join(DATA_DIR, 'arkas_meta.json')
USERDATA_FILE = os.path.join(DATA_DIR, 'arkas_userdata.json')

MONTHS = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli',
          'Agustus', 'September', 'Oktober', 'November', 'Desember']

# ---------------------------------------------------------------- helpers
def load_json(path, default):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return default

def save_json(path, data):
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)

def money(s):
    if s is None:
        return 0
    s = str(s).strip()
    if not s:
        return 0
    return int(re.sub(r'[^0-9]', '', s))

def money_fmt(n):
    return f"{n:,}".replace(',', '.')

def get_data():
    meta = load_json(META_FILE, {})
    months = {}
    raw = load_json(DATA_FILE, {})
    for m in MONTHS:
        if m in raw:
            months[m] = raw[m]
        else:
            months[m] = {'rows': [], 'total': None}
    return {'school': meta, 'months': months}

# ---------------------------------------------------------------- excel
THIN = Side(style='thin', color='B0B0B0')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
HDR_FILL = PatternFill('solid', fgColor='1F4E79')
SUB_FILL = PatternFill('solid', fgColor='D9E2F3')
STD_FILL = PatternFill('solid', fgColor='BDD7EE')
TOT_FILL = PatternFill('solid', fgColor='FFF2CC')
HDR_FONT = Font(color='FFFFFF', bold=True, size=10)
TITLE_FONT = Font(bold=True, size=13)
BOLD = Font(bold=True, size=10)
NORM = Font(size=10)
WRAP = Alignment(wrap_text=True, vertical='top')
LEFT = Alignment(horizontal='left', vertical='top')
RIGHT = Alignment(horizontal='right', vertical='top')
CENTER = Alignment(horizontal='center', vertical='top')

def sheet_header(ws, title, school, ncols):
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    c = ws.cell(row=1, column=1, value=title)
    c.font = TITLE_FONT
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
    c = ws.cell(row=2, column=1, value=f"{school.get('nama_sekolah','')}  |  NPSN {school.get('npsn','')}  |  TA {school.get('ta','')}  |  {school.get('sumber_dana','')}")
    c.font = Font(size=9, italic=True, color='555555')

def apply_table_row(ws, r, vals, fill=None, font=None, align=None):
    for ci, v in enumerate(vals, start=1):
        cell = ws.cell(row=r, column=ci, value=v)
        cell.border = BORDER
        if font:
            cell.font = font
        else:
            cell.font = NORM
        if align:
            cell.alignment = align
        if fill:
            cell.fill = fill

def is_leaf(row):
    return bool(row.get('rekening')) or bool(row.get('_added')) or \
           str(row.get('no', '')).startswith('A') or str(row.get('_id', '')).startswith('A')

def id_of(row):
    return str(row.get('_id') or row.get('no', ''))

def descendant_sums(rows):
    """Return function desc(path) = sum of leaf jumlah under a code path."""
    direct = {}
    for r in rows:
        if is_leaf(r):
            p = tuple(x for x in [r.get('L1'), r.get('L2'), r.get('L3')] if x)
            direct[p] = direct.get(p, 0) + money(r.get('jumlah'))

    def desc(path):
        total = 0
        for p, v in direct.items():
            if len(p) >= len(path) and p[:len(path)] == path:
                total += v
        return total
    return desc

def render_rows(ws, start, rows, is_perubahan=False):
    """rows: list of row dicts. Writes hierarchical table. Returns next row index."""
    r = start
    headers = ['No', 'Uraian', 'Kode Rekening', 'Volume', 'Satuan', 'Tarif Harga', 'Jumlah (Rp)']
    if is_perubahan:
        headers = ['No', 'Uraian', 'Kode Rekening', 'Volume', 'Satuan', 'Tarif Harga',
                   'Sebelum (Rp)', 'Sesudah (Rp)', 'Selisih (Rp)']
    apply_table_row(ws, r, headers, fill=HDR_FILL, font=HDR_FONT, align=CENTER)
    r += 1
    for row in rows:
        uraian = row.get('uraian', '')
        if is_perubahan:
            vals = [row.get('no', ''), uraian, row.get('rekening', ''),
                    row.get('volume', ''), row.get('satuan', ''), row.get('tarif', ''),
                    row.get('jumlah_sebelum', ''), row.get('jumlah', ''),
                    row.get('selisih', '')]
        else:
            vals = [row.get('no', ''), uraian, row.get('rekening', ''),
                    row.get('volume', ''), row.get('satuan', ''), row.get('tarif', ''),
                    row.get('jumlah', '')]
        fill = None
        font = NORM
        if not is_leaf(row):
            if not row.get('L2'):
                fill, font = STD_FILL, BOLD
            else:
                fill, font = SUB_FILL, BOLD
        apply_table_row(ws, r, vals, fill=fill, font=font, align=WRAP)
        for ci in (7,) if not is_perubahan else (7, 8, 9):
            ws.cell(row=r, column=ci).alignment = RIGHT
        r += 1
    return r

def total_row(ws, r, label, value, ncols, amount_col):
    apply_table_row(ws, r, [label] + [''] * (ncols - 1), fill=TOT_FILL, font=BOLD)
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols - 1)
    c = ws.cell(row=r, column=ncols, value=value)
    c.font = BOLD
    c.fill = TOT_FILL
    c.border = BORDER
    c.alignment = RIGHT
    return r + 1

def build_rkas_workbook():
    data = get_data()
    school = data['school']
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    # Rekap sheet
    ws = wb.create_sheet('REKAP')
    ws.append(['REKAPITULASI ANGGARAN BOSP REGULER TA 2026'])
    ws['A1'].font = TITLE_FONT
    ws.append([f"{school.get('nama_sekolah','')}  |  NPSN {school.get('npsn','')}"])
    ws.append([])
    hdr = ['No', 'Bulan', 'Anggaran Belanja (Rp)']
    apply_table_row(ws, 4, hdr, fill=HDR_FILL, font=HDR_FONT, align=CENTER)
    r = 5
    annual = 0
    for i, m in enumerate(MONTHS, 1):
        total = money(data['months'][m].get('total'))
        annual += total
        apply_table_row(ws, r, [i, m, money_fmt(total)], align=WRAP)
        ws.cell(row=r, column=3).alignment = RIGHT
        r += 1
    apply_table_row(ws, r, ['', 'TOTAL BELANJA', money_fmt(annual)], fill=TOT_FILL, font=BOLD)
    ws.cell(row=r, column=3).alignment = RIGHT
    r += 1
    penerimaan = money(school.get('total_penerimaan'))
    apply_table_row(ws, r, ['', 'TOTAL PENERIMAAN', money_fmt(penerimaan)], font=BOLD)
    ws.cell(row=r, column=3).alignment = RIGHT
    r += 1
    apply_table_row(ws, r, ['', 'SISA ANGGARAN', money_fmt(penerimaan - annual)], font=BOLD)
    ws.cell(row=r, column=3).alignment = RIGHT
    for col, w in zip('ABC', (8, 22, 22)):
        ws.column_dimensions[col].width = w
    # per-month sheets
    for m in MONTHS:
        ws = wb.create_sheet(m[:3].upper())
        sheet_header(ws, f'RINCIAN KERTAS KERJA PERBULAN - {m} 2026', school, 7)
        rows = data['months'][m]['rows']
        r = render_rows(ws, 4, rows)
        r = total_row(ws, r, 'JUMLAH', data['months'][m].get('total'), 7, 7)
        widths = [5, 58, 18, 10, 14, 12, 14]
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = w
    return wb

def build_perubahan_workbook(userdata):
    data = get_data()
    school = data['school']
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    revisi = userdata.get('revisi', {})
    any_rev = any(revisi.get(m) and revisi[m].get('rows') for m in MONTHS)
    if not any_rev:
        ws = wb.create_sheet('INFO')
        ws['A1'] = 'Belum ada data perubahan anggaran. Lakukan revisi pada modul ARKAS PERUBAHAN terlebih dahulu.'
        return wb
    # rekap perubahan
    ws = wb.create_sheet('REKAP PERUBAHAN')
    ws.append(['REKAP PERUBAHAN ANGGARAN (SEBELUM vs SESUDAH)'])
    ws['A1'].font = TITLE_FONT
    ws.append([f"{school.get('nama_sekolah','')}  |  TA {school.get('ta','')}"])
    ws.append([])
    apply_table_row(ws, 4, ['Bulan', 'Sebelum (Rp)', 'Sesudah (Rp)', 'Selisih (Rp)'],
                    fill=HDR_FILL, font=HDR_FONT, align=CENTER)
    r = 5
    tot_before = tot_after = 0
    for m in MONTHS:
        rev = revisi.get(m) or {}
        rows = rev.get('rows')
        if not rows:
            continue
        before = money(data['months'][m].get('total'))
        after = sum(money(x.get('jumlah')) for x in rows if is_leaf(x))
        tot_before += before
        tot_after += after
        apply_table_row(ws, r, [m, money_fmt(before), money_fmt(after), money_fmt(after - before)])
        for c in (2, 3, 4):
            ws.cell(row=r, column=c).alignment = RIGHT
        r += 1
    apply_table_row(ws, r, ['TOTAL', money_fmt(tot_before), money_fmt(tot_after),
                            money_fmt(tot_after - tot_before)], fill=TOT_FILL, font=BOLD)
    for c in (2, 3, 4):
        ws.cell(row=r, column=c).alignment = RIGHT
    for col, w in zip('ABCD', (16, 16, 16, 16)):
        ws.column_dimensions[col].width = w
    # per-month perubahan sheets
    for m in MONTHS:
        rev = revisi.get(m) or {}
        rows = rev.get('rows')
        if not rows:
            continue
        orig_by_no = {str(x['no']): x for x in data['months'][m]['rows']}
        desc = descendant_sums(rows)
        disp_rows = []
        for row in rows:
            nr = dict(row)
            p = tuple(x for x in [row.get('L1'), row.get('L2'), row.get('L3')] if x)
            before = 0
            if is_leaf(row):
                orig = orig_by_no.get(str(row.get('no')))
                before = money(orig['jumlah']) if orig else 0
            else:
                orig = orig_by_no.get(str(row.get('no')))
                before = money(orig['jumlah']) if orig else desc(p)
            sesudah = money(row.get('jumlah')) if is_leaf(row) else desc(p)
            nr['jumlah_sebelum'] = money_fmt(before)
            nr['jumlah'] = money_fmt(sesudah)
            nr['selisih'] = money_fmt(sesudah - before)
            disp_rows.append(nr)
        ws = wb.create_sheet('PER-' + m[:3].upper())
        sheet_header(ws, f'RINCIAN KERTAS KERJA PERUBAHAN - {m} 2026', school, 9)
        r = render_rows(ws, 4, disp_rows, is_perubahan=True)
        before = money(data['months'][m].get('total'))
        after = sum(money(x.get('jumlah')) for x in disp_rows if is_leaf(x))
        r = total_row(ws, r, 'JUMLAH SEBELUM', money_fmt(before), 9, 7)
        r = total_row(ws, r, 'JUMLAH SESUDAH', money_fmt(after), 9, 8)
        r = total_row(ws, r, 'SELISIH', money_fmt(after - before), 9, 9)
        widths = [5, 52, 18, 10, 14, 12, 14, 14, 14]
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = w
    return wb

def build_realisasi_workbook(userdata):
    data = get_data()
    school = data['school']
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    real = userdata.get('realisasi', {})
    any_real = any(real.get(m) for m in MONTHS)
    if not any_real:
        ws = wb.create_sheet('INFO')
        ws['A1'] = 'Belum ada data realisasi. Isi realisasi pada modul ARKAS PERUBAHAN terlebih dahulu.'
        return wb
    ws = wb.create_sheet('REKAP REALISASI')
    ws.append(['REKAP REALISASI ANGGARAN TA 2026'])
    ws['A1'].font = TITLE_FONT
    ws.append([f"{school.get('nama_sekolah','')}"])
    ws.append([])
    apply_table_row(ws, 4, ['Bulan', 'Anggaran (Rp)', 'Realisasi (Rp)', 'Sisa (Rp)', '% Serapan'],
                    fill=HDR_FILL, font=HDR_FONT, align=CENTER)
    r = 5
    t_ang = t_real = 0
    for m in MONTHS:
        ang = money(data['months'][m].get('total'))
        realisasi = sum(int(v or 0) for v in (real.get(m) or {}).values())
        t_ang += ang
        t_real += realisasi
        pct = (realisasi / ang * 100) if ang else 0
        apply_table_row(ws, r, [m, money_fmt(ang), money_fmt(realisasi),
                                money_fmt(ang - realisasi), f'{pct:.1f}%'])
        for c in (2, 3, 4):
            ws.cell(row=r, column=c).alignment = RIGHT
        ws.cell(row=r, column=5).alignment = CENTER
        r += 1
    pct_t = (t_real / t_ang * 100) if t_ang else 0
    apply_table_row(ws, r, ['TOTAL', money_fmt(t_ang), money_fmt(t_real),
                            money_fmt(t_ang - t_real), f'{pct_t:.1f}%'],
                    fill=TOT_FILL, font=BOLD)
    for c in (2, 3, 4):
        ws.cell(row=r, column=c).alignment = RIGHT
    ws.cell(row=r, column=5).alignment = CENTER
    for col, w in zip('ABCDE', (16, 18, 18, 18, 12)):
        ws.column_dimensions[col].width = w
    # per-month detail
    for m in MONTHS:
        if not real.get(m):
            continue
        rev = (userdata.get('revisi') or {}).get(m) or {}
        rows = rev.get('rows') if rev.get('rows') else data['months'][m]['rows']
        ws = wb.create_sheet('REAL-' + m[:3].upper())
        sheet_header(ws, f'REALISASI ANGGARAN - {m} 2026', school, 6)
        apply_table_row(ws, 4, ['No', 'Uraian', 'Kode Rekening', 'Anggaran (Rp)',
                                'Realisasi (Rp)', '%'], fill=HDR_FILL, font=HDR_FONT, align=CENTER)
        r = 5
        ang_m = 0
        real_m = 0
        for row in rows:
            if not is_leaf(row):
                continue
            rid = f"{m}|{id_of(row)}"
            anggaran = money(row.get('jumlah'))
            realisasi = int((real.get(m) or {}).get(rid, 0) or 0)
            ang_m += anggaran
            real_m += realisasi
            pct = (realisasi / anggaran * 100) if anggaran else 0
            apply_table_row(ws, r, [id_of(row), row['uraian'], row.get('rekening', ''),
                                    money_fmt(anggaran), money_fmt(realisasi), f'{pct:.1f}%'])
            for c in (4, 5):
                ws.cell(row=r, column=c).alignment = RIGHT
            ws.cell(row=r, column=6).alignment = CENTER
            r += 1
        pct_m = (real_m / ang_m * 100) if ang_m else 0
        apply_table_row(ws, r, ['', 'TOTAL', '', money_fmt(ang_m), money_fmt(real_m), f'{pct_m:.1f}%'],
                        fill=TOT_FILL, font=BOLD)
        for c in (4, 5):
            ws.cell(row=r, column=c).alignment = RIGHT
        ws.cell(row=r, column=6).alignment = CENTER
        for col, w in zip('ABCDEF', (5, 50, 18, 16, 16, 10)):
            ws.column_dimensions[col].width = w
    return wb

def school_with_userdata(userdata):
    school = dict(get_data()['school'])
    extra = (userdata or {}).get('school') or {}
    for k, v in extra.items():
        if v not in (None, ''):
            school[k] = v
    return school

def jenis_of(row):
    r = (row.get('rekening') or '').strip()
    if r.startswith('5.2'):
        return '1.3', 'BELANJA MODAL'
    return '1.2', 'BELANJA BARANG DAN JASA'

def annual_aggregate(data):
    """Aggregate monthly rows into annual RKAS tree (BELANJA LANGSUNG -> jenis -> SNP -> komponen -> kegiatan -> leaves)."""
    leaf_agg = {}
    order = []
    header = {}
    for mi, m in enumerate(MONTHS):
        for r in data['months'][m].get('rows', []):
            p = tuple(x for x in [r.get('L1'), r.get('L2'), r.get('L3')] if x)
            if not p:
                continue
            if is_leaf(r):
                jk, jn = jenis_of(r)
                id_ = (jk,) + p + ((r.get('rekening') or '').strip(), (r.get('uraian') or '').strip())
                if id_ not in leaf_agg:
                    leaf_agg[id_] = {'path': p, 'jenis': jk, 'jenis_nama': jn,
                                     'uraian': r.get('uraian', ''), 'rekening': r.get('rekening', ''),
                                     'total': 0, 'tw': [0, 0, 0, 0], 'vol': 0, 'sats': {}, 'tarifs': {}}
                    order.append(id_)
                a = leaf_agg[id_]
                v = money(r.get('jumlah'))
                a['total'] += v
                a['tw'][mi // 3] += v
                vs = re.sub(r'[^0-9]', '', str(r.get('volume') or '0')) or '0'
                a['vol'] += int(vs)
                s = (r.get('satuan') or '').strip()
                if s:
                    a['sats'][s] = a['sats'].get(s, 0) + 1
                if r.get('tarif'):
                    tv = money(r.get('tarif'))
                    a['tarifs'][tv] = a['tarifs'].get(tv, 0) + 1
            else:
                header[p] = {'uraian': r.get('uraian', ''), 'no': r.get('no', '')}
    root = {'name': 'BELANJA LANGSUNG', 'code': '1', 'children': [], 'leaves': [],
            'total': 0, 'tw': [0, 0, 0, 0], 'map': {}}
    jenis_nodes = {}
    for jk in ('1.2', '1.3'):
        jn = 'BELANJA BARANG DAN JASA' if jk == '1.2' else 'BELANJA MODAL'
        node = {'name': jn, 'code': jk, 'children': [], 'leaves': [],
                'total': 0, 'tw': [0, 0, 0, 0], 'map': {}}
        jenis_nodes[jk] = node
        root['children'].append(node)

    def ensure(node, path):
        cur = node
        for i in range(len(path)):
            key = path[:i + 1]
            if key not in cur['map']:
                h = header.get(key, {})
                child = {'name': h.get('uraian', ''), 'code': '.'.join(path[:i + 1]),
                         'children': [], 'leaves': [], 'total': 0, 'tw': [0, 0, 0, 0], 'map': {}}
                cur['map'][key] = child
                cur['children'].append(child)
            cur = cur['map'][key]
        return cur

    for id_ in order:
        a = leaf_agg[id_]
        node = ensure(jenis_nodes[a['jenis']], a['path'])
        node['leaves'].append(a)

    def sumnode(node):
        s = sum(l['total'] for l in node['leaves'])
        tw = [0, 0, 0, 0]
        for l in node['leaves']:
            for i in range(4):
                tw[i] += l['tw'][i]
        for c in node['children']:
            s += sumnode(c)
            for i in range(4):
                tw[i] += c['tw'][i]
        node['total'] = s
        node['tw'] = tw
        return s

    sumnode(root)
    return root

def strip_zero(code):
    return '.'.join([(p.lstrip('0') or '0') for p in str(code).split('.')])

def build_rkas_resmi_workbook(userdata):
    data = get_data()
    school = school_with_userdata(userdata)
    root = annual_aggregate(data)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'RKAS RESMI'
    ws.merge_cells('A1:L1')
    c = ws['A1']
    c.value = 'RENCANA KEGIATAN DAN ANGGARAN SEKOLAH (RKAS)'
    c.font = Font(bold=True, size=14)
    c.alignment = Alignment(horizontal='center')
    ws.merge_cells('A2:L2')
    c = ws['A2']
    c.value = 'TAHUN ANGGARAN ' + str(school.get('ta', ''))
    c.font = Font(bold=True, size=11)
    c.alignment = Alignment(horizontal='center')

    ident = [
        ('NAMA SEKOLAH', school.get('nama_sekolah', '')),
        ('KAMPUNG/DISTRIK', school.get('desa_kecamatan', '')),
        ('KABUPATEN/KOTA', school.get('kabupaten', '')),
        ('PROVINSI', school.get('provinsi', '')),
        ('SUMBER DANA', school.get('sumber_dana', '')),
    ]
    r = 4
    for lbl, val in ident:
        cell = ws.cell(row=r, column=1, value=lbl + '  :  ' + str(val))
        cell.font = BOLD
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=5)
        r += 1

    pr = 4
    for col, txt in ((7, 'URAIAN'), (8, 'JUMLAH URAIAN')):
        cell = ws.cell(row=pr, column=col, value=txt)
        cell.font = HDR_FONT
        cell.fill = HDR_FILL
        cell.border = BORDER
        cell.alignment = Alignment(horizontal='center', vertical='center')
    ws.merge_cells(start_row=pr, start_column=7, end_row=pr + 1, end_column=7)
    ws.merge_cells(start_row=pr, start_column=8, end_row=pr + 1, end_column=8)
    ws.merge_cells(start_row=pr, start_column=9, end_row=pr, end_column=12)
    cell = ws.cell(row=pr, column=9, value='DITERIMA (TRIWULAN)')
    cell.font = HDR_FONT
    cell.fill = HDR_FILL
    cell.border = BORDER
    cell.alignment = Alignment(horizontal='center', vertical='center')
    for col, txt in ((9, 'TRIWULAN I'), (10, 'TRIWULAN II'), (11, 'TRIWULAN III'), (12, 'TRIWULAN IV')):
        cell = ws.cell(row=pr + 1, column=col, value=txt)
        cell.font = HDR_FONT
        cell.fill = HDR_FILL
        cell.border = BORDER
        cell.alignment = CENTER
    for col in (7, 8):
        ws.cell(row=pr + 1, column=col).border = BORDER

    pagu = money(school.get('pagu_awal_bos'))
    sisa_lalu = money(school.get('sisa_dana_bos_tahun_lalu'))
    jasa = money(school.get('jasa_bunga_bank'))
    total_terima = pagu + sisa_lalu + jasa
    diterima = [money(school.get('diterima_tw' + str(i))) for i in range(1, 5)]
    if sum(diterima) == 0:
        diterima = [0, 0, 0, total_terima]
    rows_p = [
        ('PAGU AWAL BOS ' + str(school.get('ta', '')), pagu, diterima[0]),
        ('SISA DANA BOS TAHUN LALU', sisa_lalu, diterima[1]),
        ('JASA/BUNGA BANK TAHUN ' + str(school.get('ta', '')), jasa, diterima[2]),
        ('TOTAL PENERIMAAN BOS', total_terima, diterima[3]),
    ]
    rr = pr + 2
    for idx, (lbl, jml, twv) in enumerate(rows_p):
        ws.cell(row=rr, column=7, value=lbl).border = BORDER
        ws.cell(row=rr, column=8, value=money_fmt(jml)).border = BORDER
        ws.cell(row=rr, column=8).alignment = RIGHT
        for ci in range(9, 13):
            ws.cell(row=rr, column=ci).border = BORDER
        ws.cell(row=rr, column=9 + idx, value=money_fmt(twv)).border = BORDER
        ws.cell(row=rr, column=9 + idx).alignment = RIGHT
        rr += 1
    ws.cell(row=rr, column=7, value='DANA BOS — TOTAL').font = BOLD
    ws.cell(row=rr, column=7).border = BORDER
    for ci in range(8, 13):
        ws.cell(row=rr, column=ci).border = BORDER
    ws.cell(row=rr, column=8, value=money_fmt(total_terima)).border = BORDER
    ws.cell(row=rr, column=8).alignment = RIGHT
    ws.cell(row=rr, column=12, value=money_fmt(sum(diterima))).border = BORDER
    ws.cell(row=rr, column=12).alignment = RIGHT

    rr += 2
    ws.cell(row=rr, column=1, value='NAMA BANK').font = BOLD
    ws.merge_cells(start_row=rr, start_column=2, end_row=rr, end_column=4)
    ws.cell(row=rr, column=2, value=str(school.get('nama_bank') or '')).border = BORDER
    ws.cell(row=rr, column=7, value='NO. REKENING').font = BOLD
    ws.merge_cells(start_row=rr, start_column=8, end_row=rr, end_column=10)
    ws.cell(row=rr, column=8, value=str(school.get('no_rekening') or '')).border = BORDER
    rr += 1
    ws.cell(row=rr, column=1, value='ATAS NAMA REKENING').font = BOLD
    ws.merge_cells(start_row=rr, start_column=2, end_row=rr, end_column=6)
    ws.cell(row=rr, column=2, value=str(school.get('atas_nama_rekening') or '')).border = BORDER

    rr += 2
    heads = ['No. Urut', 'Kode Rekening', 'BELANJA / OUTPUT (SNP) / KOMPONEN / KEGIATAN / DETIL BIAYA',
             'RINCIAN PERHITUNGAN', 'VOLUME', 'SATUAN', 'TARIF SATUAN (Rp)',
             'JUMLAH (Rp)', 'TRIWULAN I', 'TRIWULAN II', 'TRIWULAN III', 'TRIWULAN IV']
    for ci, htxt in enumerate(heads, 1):
        cell = ws.cell(row=rr, column=ci, value=htxt)
        cell.font = HDR_FONT
        cell.fill = HDR_FILL
        cell.border = BORDER
        cell.alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')
    rr += 1

    no_urut = [0]

    def render_node(node, depth):
        nonlocal rr
        no_urut[0] += 1
        code_disp = '1' if depth == 0 else strip_zero(node['code'])
        vals = [no_urut[0], code_disp, node['name'], '', '', '', '',
                money_fmt(node['total']),
                money_fmt(node['tw'][0]), money_fmt(node['tw'][1]),
                money_fmt(node['tw'][2]), money_fmt(node['tw'][3])]
        fill = STD_FILL if depth == 1 else (SUB_FILL if depth == 2 else None)
        for ci, v in enumerate(vals, 1):
            cell = ws.cell(row=rr, column=ci, value=v)
            cell.border = BORDER
            cell.font = BOLD if depth <= 2 else NORM
            if fill:
                cell.fill = fill
        for ci in (8, 9, 10, 11, 12):
            ws.cell(row=rr, column=ci).alignment = RIGHT
        rr += 1
        for c in node['children']:
            render_node(c, depth + 1)
        for l in node['leaves']:
            no_urut[0] += 1
            sats = sorted(l['sats'].items(), key=lambda kv: -kv[1])
            satuan = sats[0][0] if sats else ''
            tars = sorted(l['tarifs'].items(), key=lambda kv: -kv[1])
            tarif = money_fmt(tars[0][0]) if tars else ''
            vol_s = f"{l['vol']:,}".replace(',', '.') if l['vol'] else ''
            rincian = (vol_s + (' ' + satuan if satuan else '')) if l['vol'] else ''
            uraian_val = l['uraian']
            if l['rekening']:
                uraian_val += '\n' + l['rekening']
            vals = [no_urut[0], strip_zero('.'.join(l['path'])), uraian_val,
                    rincian, vol_s, satuan, tarif,
                    money_fmt(l['total']),
                    money_fmt(l['tw'][0]), money_fmt(l['tw'][1]),
                    money_fmt(l['tw'][2]), money_fmt(l['tw'][3])]
            for ci, v in enumerate(vals, 1):
                cell = ws.cell(row=rr, column=ci, value=v)
                cell.border = BORDER
                cell.font = NORM
                if ci == 3:
                    cell.alignment = Alignment(wrap_text=True, vertical='top', horizontal='left')
                elif ci in (8, 9, 10, 11, 12):
                    cell.alignment = Alignment(horizontal='right', vertical='top')
            for ci in (8, 9, 10, 11, 12):
                ws.cell(row=rr, column=ci).alignment = RIGHT
            rr += 1

    render_node(root, 0)
    vals = ['', '', 'TOTAL BELANJA', '', '', '', '', money_fmt(root['total']),
            money_fmt(root['tw'][0]), money_fmt(root['tw'][1]),
            money_fmt(root['tw'][2]), money_fmt(root['tw'][3])]
    for ci, v in enumerate(vals, 1):
        cell = ws.cell(row=rr, column=ci, value=v)
        cell.border = BORDER
        cell.font = BOLD
        cell.fill = TOT_FILL
    for ci in (8, 9, 10, 11, 12):
        ws.cell(row=rr, column=ci).alignment = RIGHT
    rr += 2
    ws.merge_cells(start_row=rr, start_column=1, end_row=rr, end_column=4)
    ws.cell(row=rr, column=1, value='Komite Sekolah').alignment = CENTER
    ws.merge_cells(start_row=rr, start_column=5, end_row=rr, end_column=8)
    ws.cell(row=rr, column=5, value='Kepala Sekolah').alignment = CENTER
    ws.merge_cells(start_row=rr, start_column=9, end_row=rr, end_column=12)
    ws.cell(row=rr, column=9, value='Bendahara Sekolah').alignment = CENTER
    rr += 3
    ws.merge_cells(start_row=rr, start_column=1, end_row=rr, end_column=4)
    cell = ws.cell(row=rr, column=1, value=school.get('komite_sekolah', ''))
    cell.alignment = CENTER
    cell.font = BOLD
    ws.merge_cells(start_row=rr, start_column=5, end_row=rr, end_column=8)
    cell = ws.cell(row=rr, column=5, value=school.get('kepala_sekolah', ''))
    cell.alignment = CENTER
    cell.font = BOLD
    ws.merge_cells(start_row=rr, start_column=9, end_row=rr, end_column=12)
    cell = ws.cell(row=rr, column=9, value=school.get('bendahara', ''))
    cell.alignment = CENTER
    cell.font = BOLD
    widths = [6, 16, 42, 18, 8, 10, 12, 13, 12, 12, 12, 12]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    return wb

def build_spj_workbook(userdata):
    data = get_data()
    school = data['school']
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    spj = userdata.get('spj', {})
    any_spj = any(spj.get(m) for m in MONTHS)
    if not any_spj:
        ws = wb.create_sheet('INFO')
        ws['A1'] = 'Belum ada catatan SPJ. Isi pada tab Catatan SPJ terlebih dahulu.'
        return wb
    ws = wb.create_sheet('REKAP SPJ')
    ws.append(['REKAP CATATAN SPJ TA 2026'])
    ws['A1'].font = TITLE_FONT
    ws.append([f"{school.get('nama_sekolah','')}  |  NPSN {school.get('npsn','')}"])
    ws.append([])
    apply_table_row(ws, 4, ['Bulan', 'Nomor SPJ', 'Tanggal', 'Uraian', 'Nilai (Rp)', 'Bukti / Keterangan'],
                    fill=HDR_FILL, font=HDR_FONT, align=CENTER)
    r = 5
    total = 0
    for m in MONTHS:
        s = spj.get(m) or {}
        if not s:
            continue
        nilai = money(s.get('nilai'))
        total += nilai
        apply_table_row(ws, r, [m, s.get('nomor', ''), s.get('tanggal', ''),
                                s.get('uraian', ''), money_fmt(nilai), s.get('bukti', '')], align=WRAP)
        ws.cell(row=r, column=5).alignment = RIGHT
        r += 1
    apply_table_row(ws, r, ['TOTAL', '', '', '', money_fmt(total), ''], fill=TOT_FILL, font=BOLD)
    ws.cell(row=r, column=5).alignment = RIGHT
    for col, w in zip('ABCDEF', (14, 16, 12, 40, 16, 40)):
        ws.column_dimensions[col].width = w
    return wb

def make_xlsx(wb):
    import io
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()

# ---------------------------------------------------------------- handler
class Handler(BaseHTTPRequestHandler):
    server_version = 'ARKAS/1.0'

    def log_message(self, fmt, *args):
        pass

    def _send(self, code, body, ctype):
        if isinstance(body, str):
            body = body.encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False), 'application/json; charset=utf-8')

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == '/':
            return self.serve_index()
        if path == '/healthz':
            return self._json({'ok': True, 'app': 'ARKAS 2026 SMPN 7 Sentani'})
        if path == '/api/data':
            data = get_data()
            data['userdata'] = load_json(USERDATA_FILE, {'revisi': {}, 'realisasi': {}, 'spj': {}, 'ttd': {}})
            return self._json(data)
        if path == '/export/rkas.xlsx':
            return self._send(200, make_xlsx(build_rkas_workbook()),
                              'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        if path == '/export/perubahan.xlsx':
            ud = load_json(USERDATA_FILE, {'revisi': {}, 'realisasi': {}, 'spj': {}, 'ttd': {}})
            return self._send(200, make_xlsx(build_perubahan_workbook(ud)),
                              'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        if path == '/export/realisasi.xlsx':
            ud = load_json(USERDATA_FILE, {'revisi': {}, 'realisasi': {}, 'spj': {}, 'ttd': {}})
            return self._send(200, make_xlsx(build_realisasi_workbook(ud)),
                              'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        if path == '/export/spj.xlsx':
            ud = load_json(USERDATA_FILE, {'revisi': {}, 'realisasi': {}, 'spj': {}, 'ttd': {}})
            return self._send(200, make_xlsx(build_spj_workbook(ud)),
                              'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        if path == '/export/rkas-resmi.xlsx':
            ud = load_json(USERDATA_FILE, {'revisi': {}, 'realisasi': {}, 'spj': {}, 'ttd': {}})
            return self._send(200, make_xlsx(build_rkas_resmi_workbook(ud)),
                              'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        # static files
        if path.startswith('/static/'):
            name = os.path.basename(path)
            fp = os.path.join(STATIC, name)
            if os.path.isfile(fp):
                ctype = 'text/javascript' if name.endswith('.js') else 'text/css'
                with open(fp, 'rb') as f:
                    return self._send(200, f.read(), ctype + '; charset=utf-8')
        self._json({'error': 'not found'}, 404)

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path == '/api/save':
            ln = int(self.headers.get('Content-Length', 0) or 0)
            raw = self.rfile.read(ln) if ln else b'{}'
            try:
                payload = json.loads(raw.decode('utf-8'))
            except Exception:
                return self._json({'ok': False, 'error': 'invalid json'}, 400)
            userdata = load_json(USERDATA_FILE, {'revisi': {}, 'realisasi': {}, 'spj': {}, 'ttd': {}})
            if 'revisi' in payload:
                userdata['revisi'] = payload['revisi']
            if 'realisasi' in payload:
                userdata['realisasi'] = payload['realisasi']
            if 'spj' in payload:
                userdata['spj'] = payload['spj']
            if 'ttd' in payload:
                userdata['ttd'] = payload['ttd']
            if 'school' in payload:
                userdata['school'] = payload['school']
            save_json(USERDATA_FILE, userdata)
            return self._json({'ok': True})
        self._json({'error': 'not found'}, 404)

    def serve_index(self):
        fp = os.path.join(STATIC, 'index.html')
        with open(fp, 'r', encoding='utf-8') as f:
            html = f.read()
        data = get_data()
        data['userdata'] = load_json(USERDATA_FILE, {'revisi': {}, 'realisasi': {}, 'spj': {}, 'ttd': {}})
        injected = json.dumps(data, ensure_ascii=False).replace('</', '<\\/')
        html = html.replace('__ARKAS_DATA__', injected)
        self._send(200, html, 'text/html; charset=utf-8')

def main():
    port = int(os.environ.get('PORT', 8000))
    srv = ThreadingHTTPServer(('0.0.0.0', port), Handler)
    print(f'ARKAS server listening on 0.0.0.0:{port}')
    srv.serve_forever()

if __name__ == '__main__':
    main()
