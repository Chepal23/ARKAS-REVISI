'use strict';

/* ================================================================ */
/*  ARKAS 2026 — front-end logic                                     */
/* ================================================================ */

const DATA = window.__ARKAS__ || { school: {}, months: {}, userdata: { revisi: {}, realisasi: {}, spj: {} } };
const SCHOOL = DATA.school || {};
const MONTHS = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus',
                'September','Oktober','November','Desember'];

const state = {
  userdata: DATA.userdata || { revisi: {}, realisasi: {}, spj: {} },
  currentMonth: 'Januari',
  perubahanMonth: 'Januari',
  spjMonth: 'Januari',
  perubahanMode: 'revisi',
  rkasMode: 'resmi',
};

/* ---------------------------- helpers ---------------------------- */
function money(s) {
  if (s === null || s === undefined) return 0;
  const t = String(s).replace(/[^0-9]/g, '');
  return t ? parseInt(t, 10) : 0;
}
function fmt(n) { return (n || 0).toLocaleString('id-ID'); }
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
function escAttr(s) { return esc(s); }
function pathOf(row) { return [row.L1, row.L2, row.L3].filter(Boolean); }
function pathKey(p) { return p.join('.'); }
function isPrefix(p, q) { return q.length >= p.length && p.every((x, i) => x === q[i]); }
function isLeafRow(r) { return !!(r.rekening || r._added); }

function deepClone(obj) { return JSON.parse(JSON.stringify(obj)); }

function origRows(month) {
  const m = DATA.months[month];
  if (!m) return [];
  return m.rows.map(r => Object.assign({ _id: String(r.no) }, r));
}

/* ---------- Data sekolah (meta + edit userdata.school) ----------- */
function schoolData() {
  const extra = (state.userdata.school || {});
  const merged = Object.assign({}, SCHOOL);
  Object.keys(extra).forEach(k => { if (extra[k] !== null && extra[k] !== '') merged[k] = extra[k]; });
  return merged;
}
function saveSchoolData() {
  if (!state.userdata.school) state.userdata.school = {};
  const sd = state.userdata.school;
  const fields = ['desa_kecamatan', 'nama_bank', 'no_rekening', 'atas_nama_rekening',
                  'sisa_dana_bos_tahun_lalu', 'jasa_bunga_bank',
                  'diterima_tw1', 'diterima_tw2', 'diterima_tw3', 'diterima_tw4'];
  fields.forEach(f => {
    const el = document.getElementById('sch-' + f);
    if (el) sd[f] = el.value.trim();
  });
  saveUserdata();
  renderRkasResmi();
  toast('Data sekolah & rekening tersimpan.');
}

function effRows(month) {
  const rev = state.userdata.revisi[month];
  if (rev && Array.isArray(rev.rows) && rev.rows.length) {
    return deepClone(rev.rows);
  }
  return origRows(month);
}

/* ---------------------------- tree ------------------------------- */
function buildTree(rows) {
  const root = { children: [], map: {}, leaves: [], key: '', sum: 0, uraian: '' };
  function ensure(pathArr) {
    let node = root;
    for (let i = 0; i < pathArr.length; i++) {
      const key = pathArr.slice(0, i + 1).join('.');
      if (!node.map[key]) {
        const child = { key, code: pathArr.slice(0, i + 1), uraian: '', jumlah: 0,
                        no: '', leaves: [], children: [], map: {}, sum: 0, parent: node };
        node.map[key] = child;
        node.children.push(child);
      }
      node = node.map[key];
    }
    return node;
  }
  for (const row of rows) {
    const path = pathOf(row);
    if (!path.length) continue;
    const node = ensure(path);
    if (isLeafRow(row)) {
      node.leaves.push(row);
    } else {
      node.uraian = row.uraian;
      node.jumlah = money(row.jumlah);
      node.no = row.no;
    }
  }
  return root;
}
function compute(node) {
  let s = 0;
  for (const l of node.leaves) s += money(l.jumlah);
  for (const c of node.children) s += compute(c);
  node.sum = s;
  return s;
}

/* ---------------------------- toast ------------------------------ */
let toastTimer = null;
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2200);
}

/* ---------------------------- tabs ------------------------------- */
function setTab(name) {
  document.querySelectorAll('nav.tabs button').forEach(b => {
    b.classList.toggle('active', b.dataset.tab === name);
  });
  ['dashboard','rkas','perubahan','spj','laporan'].forEach(t => {
    document.getElementById('tab-' + t).classList.toggle('hidden', t !== name);
  });
  if (name === 'dashboard') renderTrenStandar();
}

/* ---------------------------- dashboard -------------------------- */
function dashCards() {
  const totalTerima = money(SCHOOL.total_penerimaan);
  let totalAnggaran = 0, totalRealisasi = 0;
  MONTHS.forEach(m => {
    totalAnggaran += money(DATA.months[m].total);
    const real = state.userdata.realisasi[m] || {};
    Object.values(real).forEach(v => { totalRealisasi += parseInt(v || 0, 10); });
  });
  const sisa = totalTerima - totalAnggaran;
  const pct = totalAnggaran ? Math.round(totalRealisasi / totalAnggaran * 100) : 0;
  document.getElementById('dashCards').innerHTML = `
    <div class="card"><div class="k">Total Penerimaan BOSP</div><div class="v">Rp ${fmt(totalTerima)}</div><div class="bar"><span style="width:100%"></span></div></div>
    <div class="card"><div class="k">Total Anggaran 2026</div><div class="v">Rp ${fmt(totalAnggaran)}</div><div class="bar"><span style="width:${totalTerima ? totalAnggaran/totalTerima*100 : 0}%;background:#2e86c1"></span></div></div>
    <div class="card"><div class="k">Realisasi Tercatat</div><div class="v acc">Rp ${fmt(totalRealisasi)}</div><div class="bar"><span style="width:${pct}%"></span></div></div>
    <div class="card"><div class="k">Sisa Anggaran</div><div class="v ${sisa < 0 ? 'danger' : ''}">Rp ${fmt(sisa)}</div><div class="bar"><span style="width:${totalTerima ? Math.max(sisa,0)/totalTerima*100 : 0}%;background:#b9770e"></span></div></div>`;
}

function dashBars() {
  let max = 0;
  const rows = MONTHS.map(m => {
    const ang = money(DATA.months[m].total);
    const real = Object.values(state.userdata.realisasi[m] || {}).reduce((a, v) => a + parseInt(v || 0, 10), 0);
    max = Math.max(max, ang);
    return { m, ang, real };
  });
  const h = 150;
  document.getElementById('chartBars').innerHTML = rows.map(r => {
    const ha = r.ang ? Math.round(r.ang / max * h) : 0;
    const hr = r.real ? Math.round(r.real / max * h) : 0;
    return `<div class="bcol" title="${r.m}: Anggaran ${fmt(r.ang)} · Realisasi ${fmt(r.real)}">
      <div class="pair">
        <div class="bar ang" style="height:${ha}px"></div>
        <div class="bar real" style="height:${hr}px"></div>
      </div>
      <div class="blabel">${r.m.slice(0, 3)}</div>
    </div>`;
  }).join('');
}

function standarAggregate() {
  const agg = {}; // name -> {total, byMonth}
  MONTHS.forEach(m => {
    (DATA.months[m].rows || []).forEach(r => {
      if (!r.rekening && r.L1 && !r.L2) {
        const name = r.uraian.trim();
        if (!agg[name]) agg[name] = { total: 0, byMonth: {} };
        agg[name].total += money(r.jumlah);
        agg[name].byMonth[m] = money(r.jumlah);
      }
    });
  });
  return agg;
}

function renderStandarSummary() {
  const agg = standarAggregate();
  const grand = Object.values(agg).reduce((a, x) => a + x.total, 0);
  const names = Object.keys(agg).sort((a, b) => agg[b].total - agg[a].total);
  let list = `<table class="rkas" style="margin-bottom:16px">
    <thead><tr><th>Standar</th><th class="num">Total Setahun</th><th class="num">%</th><th style="width:34%">Porsi</th></tr></thead><tbody>`;
  names.forEach(n => {
    const pct = grand ? (agg[n].total / grand * 100) : 0;
    list += `<tr><td><b>${esc(n)}</b></td><td class="num">${fmt(agg[n].total)}</td>
      <td class="num">${pct.toFixed(1)}%</td>
      <td><div class="progress"><span style="width:${pct}%;background:#2e86c1"></span></div></td></tr>`;
  });
  list += `<tr class="total"><td>TOTAL</td><td class="num">${fmt(grand)}</td><td class="num">100%</td><td></td></tr></tbody></table>`;

  list += `<div style="overflow-x:auto"><table class="rkas" style="min-width:900px">
    <thead><tr><th>Standar</th>${MONTHS.map(m => `<th class="num">${m.slice(0,3)}</th>`).join('')}<th class="num">Total</th></tr></thead><tbody>`;
  names.forEach(n => {
    list += `<tr><td><b>${esc(n)}</b></td>${MONTHS.map(m => {
      const v = agg[n].byMonth[m] || 0;
      return `<td class="num">${v ? fmt(v) : '—'}</td>`;
    }).join('')}<td class="num">${fmt(agg[n].total)}</td></tr>`;
  });
  list += `<tr class="total"><td>TOTAL</td>${MONTHS.map(m =>
    `<td class="num">${fmt(money(DATA.months[m].total))}</td>`).join('')}<td class="num">${fmt(grand)}</td></tr></tbody></table></div>`;
  document.getElementById('standarSummary').innerHTML = list;
}

/* ------------------ Grafik Tren per Standar ---------------------- */
const PALETTE = ['#1f4e79','#2e86c1','#148f77','#b9770e','#8e44ad','#c0392b','#16a085','#d35400','#34495e','#7f8c8d'];
function renderTrenStandar() {
  const agg = standarAggregate();
  const names = Object.keys(agg).sort((a, b) => agg[b].total - agg[a].total);
  const sel = document.getElementById('trenStandarSel');
  if (!sel) return;
  const cur = sel.value;
  sel.innerHTML = names.map(n =>
    `<option value="${escAttr(n)}" ${n === cur ? 'selected' : ''}>${esc(n)}</option>`).join('');
  const chosen = sel.value || names[0];
  document.getElementById('trenTotal').textContent = 'Rp ' + fmt(agg[chosen] ? agg[chosen].total : 0);
  const vals = MONTHS.map(m => agg[chosen] ? (agg[chosen].byMonth[m] || 0) : 0);
  const max = Math.max(1, ...vals);
  const h = 170;
  const bars = vals.map((v, i) => {
    const hh = Math.round(v / max * h);
    const color = PALETTE[i % PALETTE.length];
    return `<div class="bcol" title="${MONTHS[i]}: ${fmt(v)}">
      <div class="tren-val">${v ? (v >= 1000000 ? (v/1000000).toFixed(1) + ' jt' : v) : '—'}</div>
      <div class="pair"><div class="bar" style="height:${hh}px;background:${color}"></div></div>
      <div class="blabel">${MONTHS[i].slice(0,3)}</div>
    </div>`;
  }).join('');
  document.getElementById('trenChart').innerHTML =
    `<div class="bars" style="height:230px">${bars}</div>`;
}

/* ---------------------------- RKAS (read-only) ------------------- */
function renderRkasChips() {
  document.getElementById('rkasChips').innerHTML = MONTHS.map(m =>
    `<button class="${m === state.currentMonth ? 'active' : ''}" onclick="setRkasMonth('${m}')">${m}</button>`).join('');
}
function setRkasMonth(m) { state.currentMonth = m; renderRkasChips(); renderRkas(); }

function renderRkas() {
  const m = state.currentMonth;
  const rows = DATA.months[m].rows || [];
  const tree = buildTree(rows);
  compute(tree);
  const total = money(DATA.months[m].total);
  const penerimaan = (SCHOOL.penerimaan && SCHOOL.penerimaan[0]) || { kode: '4.3.1.01.', uraian: SCHOOL.sumber_dana || '', jumlah: SCHOOL.total_penerimaan || '' };

  document.getElementById('rkasReport').innerHTML = `
    <div class="form-title">RINCIAN KERTAS KERJA PERBULAN</div>
    <div class="form-sub">TAHUN ANGGARAN : ${esc(SCHOOL.ta || '')}</div>
    <table class="form-identitas">
      <tr><td style="width:120px">NPSN</td><td style="width:10px">:</td><td>${esc(SCHOOL.npsn || '')}</td></tr>
      <tr><td>Nama Sekolah</td><td>:</td><td>${esc(SCHOOL.nama_sekolah || '')}</td></tr>
      <tr><td>Alamat</td><td>:</td><td>${esc(SCHOOL.alamat || '')}</td></tr>
      <tr><td>Kabupaten</td><td>:</td><td>${esc(SCHOOL.kabupaten || '')}</td></tr>
      <tr><td>Provinsi</td><td>:</td><td>${esc(SCHOOL.provinsi || '')}</td></tr>
      <tr><td>Bulan</td><td>:</td><td>${m} ${esc(SCHOOL.ta || '')}</td></tr>
      <tr><td>Sumber Dana</td><td>:</td><td>${esc(SCHOOL.sumber_dana || '')}</td></tr>
    </table>

    <div class="section-h">A. PENERIMAAN</div>
    <div class="section-line">Sumber Dana :</div>
    <table class="mini-penerimaan">
      <tr><td>No.</td><td>Kode Penerimaan</td><td class="num">Jumlah</td></tr>
      <tr><td>${esc(penerimaan.kode || '')}</td><td>${esc(penerimaan.uraian || '')}</td><td class="num">${fmt(money(penerimaan.jumlah))}</td></tr>
      <tr class="mini-total"><td></td><td>Total Penerimaan</td><td class="num">${fmt(money(penerimaan.jumlah))}</td></tr>
    </table>

    <div class="section-h">B. BELANJA</div>
    <table class="rkas" style="margin-top:6px;table-layout:fixed">
      <colgroup>
        <col style="width:34px"><col><col style="width:82px"><col style="width:60px">
        <col style="width:60px"><col style="width:70px"><col style="width:92px">
        <col style="width:118px"><col style="width:70px">
      </colgroup>
      <thead><tr><th>No.<br>Urut</th><th class="cell-uraian">Uraian</th><th>Jumlah</th><th>Volume</th><th>Satuan</th><th>Tarif<br>Harga</th><th>Rincian<br>Perhitungan</th><th>Kode<br>Rekening</th><th>Kode<br>Program</th></tr></thead>
      <tbody>${bodyRows9col()}
      <tr class="total"><td></td><td>Jumlah</td><td class="num">${fmt(total)}</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      </tbody>
    </table>
    ${signatureBlock()}`;

  function bodyRows9col() {
    let out = '';
    function walk(node, depth) {
      const cls = depth === 1 ? 'std' : (depth === 2 ? 'sub' : 'subsub');
      out += `<tr class="${cls}"><td>${esc(node.no || '')}</td><td class="cell-uraian">${esc(node.uraian || '')}</td>
        <td class="num">${fmt(node.sum)}</td><td></td><td></td><td></td><td></td>
        <td class="kode">${depth===1 ? (node.code ? node.code.join('.') + '.' : '') : ''}</td><td></td></tr>`;
      node.children.forEach(c => walk(c, depth + 1));
      node.leaves.forEach(l => {
        const kodeProg = pathOf(l).map(x => x + '.').join('');
        out += `<tr class="leaf"><td>${esc(l.no)}</td>
          <td class="cell-uraian">${esc(l.uraian)}</td>
          <td class="num">${fmt(money(l.jumlah))}</td>
          <td>${esc(l.volume)}</td><td>${esc(l.satuan)}</td>
          <td class="num">${l.tarif ? fmt(money(l.tarif)) : ''}</td>
          <td class="kode">${l.volume && l.tarif ? esc(l.volume) + ' x ' + fmt(money(l.tarif)) : ''}</td>
          <td class="kode">${esc(l.rekening)}</td><td class="kode">${kodeProg}</td></tr>`;
      });
    }
    tree.children.forEach(c => walk(c, 1));
    return out;
  }
}

/* -------------------- RKAS Tahunan (Format Resmi) ---------------- */
function stripZero(code) {
  return String(code).split('.').map(p => (p.replace(/^0+/, '') || '0')).join('.');
}
function jenisOf(row) {
  const r = (row.rekening || '').trim();
  if (r.startsWith('5.2')) return { code: '1.3', nama: 'BELANJA MODAL' };
  return { code: '1.2', nama: 'BELANJA BARANG DAN JASA' };
}
function buildAnnualTree() {
  const leafAgg = {};
  const order = [];
  const header = {};
  MONTHS.forEach((m, mi) => {
    (DATA.months[m].rows || []).forEach(r => {
      const p = pathOf(r);
      if (!p.length) return;
      if (isLeafRow(r)) {
        const j = jenisOf(r);
        const id = j.code + '|' + pathKey(p) + '|' + (r.rekening || '') + '|' + r.uraian.trim();
        if (!leafAgg[id]) {
          leafAgg[id] = { path: p, jenis: j.code, jenisNama: j.nama, uraian: r.uraian,
                          rekening: r.rekening, total: 0, tw: [0, 0, 0, 0],
                          vol: 0, sats: {}, tarifs: {} };
          order.push(id);
        }
        const a = leafAgg[id];
        const v = money(r.jumlah);
        a.total += v;
        a.tw[Math.floor(mi / 3)] += v;
        const vn = parseFloat(String(r.volume).replace(/[^0-9]/g, ''));
        if (!isNaN(vn)) a.vol += vn;
        if (r.satuan) a.sats[r.satuan] = (a.sats[r.satuan] || 0) + 1;
        if (r.tarif) { const tv = money(r.tarif); a.tarifs[tv] = (a.tarifs[tv] || 0) + 1; }
      } else {
        header[pathKey(p)] = { uraian: r.uraian, no: r.no };
      }
    });
  });
  const root = { name: 'BELANJA LANGSUNG', code: '1', children: [], leaves: [], total: 0, tw: [0, 0, 0, 0], map: {} };
  const jenisNodes = {};
  ['1.2', '1.3'].forEach(jk => {
    const node = { name: jk === '1.2' ? 'BELANJA BARANG DAN JASA' : 'BELANJA MODAL',
                   code: jk, children: [], leaves: [], total: 0, tw: [0, 0, 0, 0], map: {} };
    jenisNodes[jk] = node;
    root.children.push(node);
  });
  function ensure(node, path) {
    let cur = node;
    for (let i = 0; i < path.length; i++) {
      const key = path.slice(0, i + 1).join('.');
      if (!cur.map[key]) {
        const h = header[key] || {};
        cur.map[key] = { name: h.uraian || '', code: path.slice(0, i + 1).join('.'),
                         children: [], leaves: [], total: 0, tw: [0, 0, 0, 0], map: {} };
        cur.children.push(cur.map[key]);
      }
      cur = cur.map[key];
    }
    return cur;
  }
  order.forEach(id => {
    const a = leafAgg[id];
    ensure(jenisNodes[a.jenis], a.path).leaves.push(a);
  });
  function sumNode(node) {
    let s = 0;
    const tw = [0, 0, 0, 0];
    node.leaves.forEach(l => { s += l.total; for (let i = 0; i < 4; i++) tw[i] += l.tw[i]; });
    node.children.forEach(c => {
      s += sumNode(c);
      for (let i = 0; i < 4; i++) tw[i] += c.tw[i];
    });
    node.total = s;
    node.tw = tw;
    return s;
  }
  sumNode(root);
  return root;
}

function renderRkasResmi() {
  const sd = schoolData();
  const root = buildAnnualTree();
  const ta = sd.ta || '2026';
  const pagu = money(sd.pagu_awal_bos);
  const sisaLalu = money(sd.sisa_dana_bos_tahun_lalu);
  const jasa = money(sd.jasa_bunga_bank);
  const totalTerima = pagu + sisaLalu + jasa;
  const diterima = [1, 2, 3, 4].map(i => money(sd['diterima_tw' + i]));
  const diterimaSum = diterima.reduce((a, b) => a + b, 0);
  const diterimaEff = diterimaSum > 0 ? diterima : [0, 0, 0, totalTerima];

  let no = 0;
  function rowsHtml(node, depth) {
    let h = '';
    no += 1;
    const cls = depth === 0 ? 'std' : (depth === 1 ? 'sub' : (depth === 2 ? 'subsub' : ''));
    const code = depth === 0 ? '1' : stripZero(node.code);
    h += `<tr class="${cls}"><td class="num">${no}</td>
      <td class="kode">${esc(code)}</td>
      <td class="cell-uraian"><b>${esc(node.name || '')}</b></td>
      <td class="kode"></td><td class="num"></td><td></td><td class="num"></td>
      <td class="num">${fmt(node.total)}</td>
      <td class="num">${fmt(node.tw[0])}</td><td class="num">${fmt(node.tw[1])}</td>
      <td class="num">${fmt(node.tw[2])}</td><td class="num">${fmt(node.tw[3])}</td></tr>`;
    node.children.forEach(c => { h += rowsHtml(c, depth + 1); });
    node.leaves.forEach(l => {
      no += 1;
      const sats = Object.keys(l.sats).sort((a, b) => l.sats[b] - l.sats[a]);
      const satuan = sats[0] || '';
      const tars = Object.keys(l.tarifs).sort((a, b) => l.tarifs[b] - l.tarifs[a]);
      const tarif = tars.length ? money(tars[0]) : 0;
      const volS = l.vol ? l.vol.toLocaleString('id-ID') : '';
      const rincian = l.vol ? (volS + (satuan ? ' ' + satuan : '')) : '';
      const rek = l.rekening ? `<span class="rek-under">${esc(l.rekening)}</span>` : '';
      h += `<tr class="leaf"><td class="num">${no}</td>
        <td class="kode">${esc(stripZero(l.path.join('.')))}</td>
        <td class="cell-uraian">${esc(l.uraian)}${rek}</td>
        <td class="kode">${esc(rincian)}</td>
        <td class="num">${esc(volS)}</td><td>${esc(satuan)}</td>
        <td class="num">${tarif ? fmt(tarif) : ''}</td>
        <td class="num">${fmt(l.total)}</td>
        <td class="num">${fmt(l.tw[0])}</td><td class="num">${fmt(l.tw[1])}</td>
        <td class="num">${fmt(l.tw[2])}</td><td class="num">${fmt(l.tw[3])}</td></tr>`;
    });
    return h;
  }
  let body = '';
  root.children.forEach(c => { body += rowsHtml(c, 1); });

  document.getElementById('rkasResmiReport').innerHTML = `
    <div class="form-title" style="font-size:16px">RENCANA KEGIATAN DAN ANGGARAN SEKOLAH (RKAS)</div>
    <div class="form-sub">TAHUN ANGGARAN ${esc(ta)}</div>

    <div class="resmi-top">
      <table class="form-identitas resmi-identitas">
        <tr><td style="width:130px">NAMA SEKOLAH</td><td>:</td><td>${esc(sd.nama_sekolah || '')}</td></tr>
        <tr><td>KAMPUNG/DISTRIK</td><td>:</td><td><input class="edit-in inline" id="sch-desa_kecamatan" value="${escAttr(sd.desa_kecamatan || '')}"></td></tr>
        <tr><td>KABUPATEN/KOTA</td><td>:</td><td>${esc(sd.kabupaten || '')}</td></tr>
        <tr><td>PROVINSI</td><td>:</td><td>${esc(sd.provinsi || '')}</td></tr>
        <tr><td>SUMBER DANA</td><td>:</td><td>${esc(sd.sumber_dana || '')}</td></tr>
      </table>
      <table class="resmi-penerimaan">
        <tr><th rowspan="2" style="vertical-align:middle;text-align:center">URAIAN</th><th rowspan="2" style="vertical-align:middle;text-align:center">JUMLAH URAIAN</th><th colspan="4" style="text-align:center">DITERIMA (TRIWULAN)</th></tr>
        <tr><th>TRIWULAN I</th><th>TRIWULAN II</th><th>TRIWULAN III</th><th>TRIWULAN IV</th></tr>
        <tr><td>PAGU AWAL BOS ${esc(ta)}</td><td class="num">${fmt(pagu)}</td>
            <td><input class="edit-in num-in" id="sch-diterima_tw1" value="${money(sd.diterima_tw1) || ''}" placeholder="0"></td>
            <td class="num"></td><td class="num"></td><td class="num"></td></tr>
        <tr><td>SISA DANA BOS TAHUN LALU</td><td class="num"><input class="edit-in num-in" id="sch-sisa_dana_bos_tahun_lalu" value="${money(sd.sisa_dana_bos_tahun_lalu) || ''}" placeholder="0"></td>
            <td><input class="edit-in num-in" id="sch-diterima_tw2" value="${money(sd.diterima_tw2) || ''}" placeholder="0"></td>
            <td class="num"></td><td class="num"></td><td class="num"></td></tr>
        <tr><td>JASA/BUNGA BANK TAHUN ${esc(ta)}</td><td class="num"><input class="edit-in num-in" id="sch-jasa_bunga_bank" value="${money(sd.jasa_bunga_bank) || ''}" placeholder="0"></td>
            <td><input class="edit-in num-in" id="sch-diterima_tw3" value="${money(sd.diterima_tw3) || ''}" placeholder="0"></td>
            <td class="num"></td><td class="num"></td><td class="num"></td></tr>
        <tr><td>TOTAL PENERIMAAN BOS</td><td class="num"><b>${fmt(totalTerima)}</b></td>
            <td><input class="edit-in num-in" id="sch-diterima_tw4" value="${money(sd.diterima_tw4) || ''}" placeholder="0"></td>
            <td class="num"></td><td class="num"></td><td class="num"></td></tr>
        <tr class="mini-total"><td>DANA BOS — TOTAL</td><td class="num"><b>${fmt(totalTerima)}</b></td><td colspan="4" class="num"><b>${fmt(diterimaEff.reduce((a, b) => a + b, 0))}</b></td></tr>
      </table>
    </div>

    <table class="form-identitas resmi-bank">
      <tr>
        <td style="width:130px">NAMA BANK</td><td>:</td>
        <td><input class="edit-in inline" id="sch-nama_bank" value="${escAttr(sd.nama_bank || '')}"></td>
        <td style="width:120px;padding-left:16px">NO. REKENING</td><td>:</td>
        <td><input class="edit-in inline" id="sch-no_rekening" value="${escAttr(sd.no_rekening || '')}"></td>
      </tr>
      <tr>
        <td>ATAS NAMA REKENING</td><td>:</td>
        <td colspan="4"><input class="edit-in inline wide" id="sch-atas_nama_rekening" value="${escAttr(sd.atas_nama_rekening || '')}"></td>
      </tr>
    </table>
    <div class="no-print" style="margin:6px 0 10px"><button class="btn sm green" onclick="saveSchoolData()">💾 Simpan Data Sekolah &amp; Rekening</button></div>

    <table class="rkas resmi" style="table-layout:fixed">
      <colgroup>
        <col style="width:30px"><col style="width:88px"><col>
        <col style="width:86px"><col style="width:52px"><col style="width:64px"><col style="width:74px">
        <col style="width:86px"><col style="width:72px"><col style="width:72px"><col style="width:72px"><col style="width:72px">
      </colgroup>
      <thead>
        <tr><th>No.<br>Urut</th><th>Kode<br>Rekening</th><th class="cell-uraian">BELANJA / OUTPUT (SNP) / KOMPONEN / KEGIATAN / DETIL BIAYA</th>
            <th>Rincian<br>Perhitungan</th><th>Volume</th><th>Satuan</th><th>Tarif<br>Satuan (Rp)</th>
            <th>Jumlah<br>(Rp)</th><th>Triwulan<br>I</th><th>Triwulan<br>II</th><th>Triwulan<br>III</th><th>Triwulan<br>IV</th></tr>
      </thead>
      <tbody>
        ${rootHtml()}
        <tr class="total"><td></td><td></td><td>TOTAL BELANJA</td><td></td><td></td><td></td><td></td>
          <td class="num">${fmt(root.total)}</td><td class="num">${fmt(root.tw[0])}</td><td class="num">${fmt(root.tw[1])}</td><td class="num">${fmt(root.tw[2])}</td><td class="num">${fmt(root.tw[3])}</td></tr>
      </tbody>
    </table>
    ${signatureBlock()}`;

  function rootHtml() {
    // "BELANJA LANGSUNG" row + its children
    let h = '';
    no = 0;
    no += 1;
    h += `<tr class="std"><td class="num">${no}</td><td class="kode">1</td>
      <td class="cell-uraian"><b>BELANJA LANGSUNG</b></td><td class="kode"></td><td class="num"></td><td></td><td class="num"></td>
      <td class="num">${fmt(root.total)}</td>
      <td class="num">${fmt(root.tw[0])}</td><td class="num">${fmt(root.tw[1])}</td>
      <td class="num">${fmt(root.tw[2])}</td><td class="num">${fmt(root.tw[3])}</td></tr>`;
    root.children.forEach(c => { h += rowsHtml(c, 1); });
    return h;
  }
}

function setRkasMode(mode) {
  state.rkasMode = mode;
  const btnResmi = document.getElementById('btnRkasResmi');
  const btnBulan = document.getElementById('btnRkasBulan');
  if (btnResmi) btnResmi.className = mode === 'resmi' ? 'btn' : 'btn ghost';
  if (btnBulan) btnBulan.className = mode === 'bulan' ? 'btn' : 'btn ghost';
  document.getElementById('rkasChips').classList.toggle('hidden', mode !== 'bulan');
  document.getElementById('rkasReport').classList.toggle('hidden', mode !== 'bulan');
  document.getElementById('rkasResmiReport').classList.toggle('hidden', mode !== 'resmi');
  const eResmi = document.getElementById('btnExportResmi');
  const eBulan = document.getElementById('btnExportBulan');
  if (eResmi) eResmi.classList.toggle('hidden', mode !== 'resmi');
  if (eBulan) eBulan.classList.toggle('hidden', mode !== 'bulan');
  if (mode === 'resmi') renderRkasResmi(); else renderRkas();
}

/* -------------------- Tanda tangan digital ----------------------- */
function sigData() {
  const s = state.userdata.ttd || {};
  return {
    kepala: { nama: s.kepala && s.kepala.nama ? s.kepala.nama : (SCHOOL.kepala_sekolah || ''), nip: (s.kepala && s.kepala.nip) || (SCHOOL.kepala_nip || ''), data: (s.kepala && s.kepala.data) || '' },
    bendahara: { nama: s.bendahara && s.bendahara.nama ? s.bendahara.nama : (SCHOOL.bendahara || ''), nip: (s.bendahara && s.bendahara.nip) || (SCHOOL.bendahara_nip || ''), data: (s.bendahara && s.bendahara.data) || '' },
    komite: { nama: s.komite && s.komite.nama ? s.komite.nama : (SCHOOL.komite_sekolah || ''), nip: (s.komite && s.komite.nip) || (SCHOOL.komite_nip || ''), data: (s.komite && s.komite.data) || '' },
    tempatTanggal: s.tempat_tanggal || SCHOOL.tempat_tanggal || '',
  };
}
function sigImgHtml(dataUrl, alt) {
  if (!dataUrl) return '';
  return `<img class="sig-img" src="${dataUrl}" alt="${escAttr(alt)}">`;
}
function signatureBlock() {
  const d = sigData();
  const img = (dataUrl, alt) => dataUrl
    ? `<div class="sig-img-area">${sigImgHtml(dataUrl, alt)}</div>`
    : `<div class="sig-img-area"></div>`;
  return `<div class="sig-row">
    <div class="sig-col">
      <div class="sig-head"><div class="sig-date"></div><div class="sig-role">Komite Sekolah</div></div>
      ${img(d.komite.data, 'ttd komite')}
      <div class="sig-line"></div>
      <div class="sig-name">${esc(d.komite.nama)}</div>
      <div class="sig-nip">${d.komite.nip ? 'NIP: ' + esc(d.komite.nip) : ''}</div>
    </div>
    <div class="sig-col">
      <div class="sig-head"><div class="sig-date"></div><div class="sig-role">Kepala Sekolah</div></div>
      ${img(d.kepala.data, 'ttd kepala')}
      <div class="sig-line"></div>
      <div class="sig-name">${esc(d.kepala.nama)}</div>
      <div class="sig-nip">NIP: ${esc(d.kepala.nip)}</div>
    </div>
    <div class="sig-col">
      <div class="sig-head"><div class="sig-date">${esc(d.tempatTanggal)}</div><div class="sig-role">Bendahara Sekolah</div></div>
      ${img(d.bendahara.data, 'ttd bendahara')}
      <div class="sig-line"></div>
      <div class="sig-name">${esc(d.bendahara.nama)}</div>
      <div class="sig-nip">NIP: ${esc(d.bendahara.nip)}</div>
    </div>
  </div>`;
}
function renderTtdManager() {
  const d = sigData();
  document.getElementById('ttdNama').innerHTML =
    `<b>${esc(d.kepala.nama)}</b><br><span style="font-size:11px;color:#64748b">NIP ${esc(d.kepala.nip)}</span>`;
  document.getElementById('ttdBendahara').innerHTML =
    `<b>${esc(d.bendahara.nama)}</b><br><span style="font-size:11px;color:#64748b">NIP ${esc(d.bendahara.nip)}</span>`;
  document.getElementById('ttdKomite').innerHTML =
    `<b>${esc(d.komite.nama)}</b><br><span style="font-size:11px;color:#64748b">NIP ${esc(d.komite.nip)}</span>`;
  document.getElementById('ttdTempatTanggal').value = d.tempatTanggal;
  ['ttdKepalaNama','ttdKepalaNip','ttdBendaharaNama','ttdBendaharaNip','ttdKomiteNama','ttdKomiteNip'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  [['ttdPrevK', d.kepala.data], ['ttdPrevB', d.bendahara.data], ['ttdPrevC', d.komite.data]].forEach(([id, dataUrl]) => {
    const el = document.getElementById(id);
    if (el) el.innerHTML = sigImgHtml(dataUrl, '') || '<span style="color:#94a3b8;font-size:12px">(belum ada)</span>';
  });
}
function attachTtd(canvasId, role) {
  const cv = document.getElementById(canvasId);
  if (!cv) return;
  const ctx = cv.getContext('2d');
  let drawing = false;
  const rect = () => { const r = cv.getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height }; };
  function pos(e) {
    const r = rect();
    const cx = (e.touches ? e.touches[0].clientX : e.clientX) - r.x;
    const cy = (e.touches ? e.touches[0].clientY : e.clientY) - r.y;
    return { x: cx * (cv.width / r.w), y: cy * (cv.height / r.h) };
  }
  function down(e) { e.preventDefault(); drawing = true; const p = pos(e); ctx.beginPath(); ctx.moveTo(p.x, p.y); }
  function move(e) {
    if (!drawing) return;
    e.preventDefault();
    const p = pos(e);
    ctx.lineTo(p.x, p.y);
    ctx.lineWidth = 2.2; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.strokeStyle = '#1f3a5f';
    ctx.stroke();
  }
  function up() { if (drawing) { drawing = false; } }
  cv.addEventListener('mousedown', down);
  cv.addEventListener('mousemove', move);
  window.addEventListener('mouseup', up);
  cv.addEventListener('touchstart', down, { passive: false });
  cv.addEventListener('touchmove', move, { passive: false });
  cv.addEventListener('touchend', up);
}
function clearCanvas(canvasId) {
  const cv = document.getElementById(canvasId);
  if (!cv) return;
  cv.getContext('2d').clearRect(0, 0, cv.width, cv.height);
}
function saveTtd(role) {
  const cv = document.getElementById('ttdCanvas-' + role);
  if (!cv) return;
  if (!state.userdata.ttd) state.userdata.ttd = {};
  const data = cv.toDataURL('image/png');
  if (!state.userdata.ttd[role]) state.userdata.ttd[role] = {};
  state.userdata.ttd[role].data = data;
  const idMap = { kepala: ['ttdKepalaNama','ttdKepalaNip'], bendahara: ['ttdBendaharaNama','ttdBendaharaNip'], komite: ['ttdKomiteNama','ttdKomiteNip'] };
  const [nId, nipId] = idMap[role];
  const nm = document.getElementById(nId).value.trim();
  const nip = document.getElementById(nipId).value.trim();
  if (nm) state.userdata.ttd[role].nama = nm;
  if (nip) state.userdata.ttd[role].nip = nip;
  state.userdata.ttd.tempat_tanggal = document.getElementById('ttdTempatTanggal').value.trim();
  saveUserdata();
  renderTtdManager();
  toast('Tanda tangan ' + role + ' tersimpan.');
}
function clearTtd(role) {
  if (state.userdata.ttd && state.userdata.ttd[role]) {
    delete state.userdata.ttd[role].data;
  }
  clearCanvas('ttdCanvas-' + role);
  saveUserdata();
  renderTtdManager();
  toast('Tanda tangan ' + role + ' dihapus.');
}
function drawSaved(role) {
  const d = sigData()[role];
  const cv = document.getElementById('ttdCanvas-' + role);
  if (!cv || !d.data) return;
  const img = new Image();
  img.onload = () => {
    const ctx = cv.getContext('2d');
    ctx.clearRect(0, 0, cv.width, cv.height);
    ctx.drawImage(img, 0, 0, cv.width, cv.height);
  };
  img.src = d.data;
}

function saveTempatTanggal() {
  if (!state.userdata.ttd) state.userdata.ttd = {};
  state.userdata.ttd.tempat_tanggal = document.getElementById('ttdTempatTanggal').value.trim();
  saveUserdata();
  toast('Tanggal & tempat disimpan.');
}

/* ------------------------- ARKAS Perubahan ----------------------- */
function setPerubahanMode(mode) {
  state.perubahanMode = mode;
  document.getElementById('btnRevTab').className = mode === 'revisi' ? 'btn' : 'btn ghost';
  document.getElementById('btnReaTab').className = mode === 'realisasi' ? 'btn' : 'btn ghost';
  document.getElementById('revPanel').classList.toggle('hidden', mode !== 'revisi');
  document.getElementById('reaPanel').classList.toggle('hidden', mode !== 'realisasi');
  if (mode === 'revisi') renderRevisi(); else renderRealisasi();
}
function renderPerubahanChips() {
  document.getElementById('perubahanMonthWrap').innerHTML = MONTHS.map(m =>
    `<button class="${m === state.perubahanMonth ? 'active' : ''}" onclick="setPerubahanMonth('${m}')">${m}</button>`).join('');
}
function setPerubahanMonth(m) {
  state.perubahanMonth = m;
  renderPerubahanChips();
  if (state.perubahanMode === 'revisi') renderRevisi(); else renderRealisasi();
}

/* --- REVISI --- */
function getWorking(month) {
  const rev = state.userdata.revisi[month];
  if (rev && Array.isArray(rev.rows)) return deepClone(rev.rows);
  return origRows(month);
}
function saveWorking(month, rows) {
  if (!state.userdata.revisi[month]) state.userdata.revisi[month] = {};
  state.userdata.revisi[month].rows = rows;
}

function renderRevisi() {
  const month = state.perubahanMonth;
  const working = getWorking(month);
  const tree = buildTree(working);
  compute(tree);
  const before = money(DATA.months[month].total);
  const after = tree.sum;
  document.getElementById('revBefore').textContent = 'Rp ' + fmt(before);
  document.getElementById('revAfter').textContent = 'Rp ' + fmt(after);
  const diff = after - before;
  const db = document.getElementById('revDiff');
  db.textContent = (diff > 0 ? '+ ' : diff < 0 ? '− ' : '') + 'Rp ' + fmt(Math.abs(diff));
  db.parentElement.className = 'diff-box ' + (diff > 0 ? 'pos' : diff < 0 ? 'neg' : '');

  let body = '';
  function nodeHtml(node, depth) {
    let h = '';
    const cls = depth === 1 ? 'std' : (depth === 2 ? 'sub' : 'subsub');
    h += `<tr class="${cls}"><td style="white-space:nowrap">
        <button class="icon-btn add" title="Tambah item di bawah ini" onclick="addLeaf('${escAttr(pathKey(node.code))}')">＋</button>
        ${depth > 1 ? `<button class="icon-btn del" title="Hapus kelompok" onclick="delSubtree('${escAttr(pathKey(node.code))}')">🗑</button>` : ''}
      </td>
      <td class="cell-uraian">${esc(node.uraian || '(kelompok)')}</td>
      <td class="kode"></td><td></td><td></td><td></td>
      <td class="num"><b id="hsum-${escAttr(pathKey(node.code))}">${fmt(node.sum)}</b></td></tr>`;
    node.children.forEach(c => { h += nodeHtml(c, depth + 1); });
    node.leaves.forEach(l => { h += leafHtml(l, depth + 1); });
    return h;
  }
  function leafHtml(l, depth) {
    return `<tr class="leaf">
      <td style="white-space:nowrap">
        <button class="icon-btn del" title="Hapus item" onclick="delLeaf('${escAttr(l._id)}')">🗑</button>
      </td>
      <td class="cell-uraian"><input class="edit-in uraian" data-id="${escAttr(l._id)}" data-f="uraian" value="${escAttr(l.uraian)}"></td>
      <td><input class="edit-in" style="max-width:130px" data-id="${escAttr(l._id)}" data-f="rekening" value="${escAttr(l.rekening)}"></td>
      <td><input class="edit-in small" data-id="${escAttr(l._id)}" data-f="volume" value="${escAttr(l.volume)}"></td>
      <td><input class="edit-in small" data-id="${escAttr(l._id)}" data-f="satuan" value="${escAttr(l.satuan)}"></td>
      <td><input class="edit-in small" type="number" data-id="${escAttr(l._id)}" data-f="tarif" value="${l.tarif ? money(l.tarif) : ''}"></td>
      <td><input class="edit-in small" type="number" data-id="${escAttr(l._id)}" data-f="jumlah" value="${l.jumlah ? money(l.jumlah) : ''}"></td>
    </tr>`;
  }
  tree.children.forEach(c => { body += nodeHtml(c, 1); });

  document.getElementById('revTable').innerHTML = `
    <table class="rkas" style="table-layout:fixed">
      <colgroup>
        <col style="width:74px"><col><col style="width:150px">
        <col style="width:80px"><col style="width:86px"><col style="width:96px"><col style="width:110px">
      </colgroup>
      <thead><tr><th>Aksi</th><th class="cell-uraian">Uraian</th><th>Kode Rekening</th><th>Volume</th><th>Satuan</th><th class="num">Tarif</th><th class="num">Jumlah</th></tr></thead>
      <tbody>${body}
      <tr class="total-extra"><td></td><td>TOTAL SESUDAH PERUBAHAN</td><td></td><td></td><td></td><td></td><td class="num" id="revTotalCell">${fmt(tree.sum)}</td></tr>
      </tbody>
    </table>`;
  document.getElementById('revTable').dataset.month = month;
}

document.addEventListener('input', (e) => {
  const t = e.target;
  if (!t.dataset || !t.dataset.id) return;
  const month = state.perubahanMonth;
  const rows = getWorking(month);
  const row = rows.find(r => r._id === t.dataset.id);
  if (!row) return;
  const f = t.dataset.f;
  row[f] = t.value;
  if (f === 'volume' || f === 'tarif') {
    const v = parseFloat(String(row.volume).replace(/\./g, ''));
    const t2 = parseFloat(String(row.tarif).replace(/\./g, ''));
    if (!isNaN(v) && !isNaN(t2)) {
      row.jumlah = String(Math.round(v * t2));
      const jIn = document.querySelector(`#revTable input[data-id="${t.dataset.id}"][data-f="jumlah"]`);
      if (jIn && document.activeElement !== jIn) jIn.value = row.jumlah;
    }
  }
  saveWorking(month, rows);
  const tree = buildTree(rows); compute(tree);
  const totalCell = document.getElementById('revTotalCell');
  if (totalCell) totalCell.textContent = fmt(tree.sum);
  document.querySelectorAll('#revTable [id^="hsum-"]').forEach(el => {
    el.textContent = fmt(tree.map[el.id.slice(5)] ? tree.map[el.id.slice(5)].sum : 0);
  });
  document.getElementById('revAfter').textContent = 'Rp ' + fmt(tree.sum);
  const before = money(DATA.months[month].total);
  const diff = tree.sum - before;
  const db2 = document.getElementById('revDiff');
  db2.textContent = (diff > 0 ? '+ ' : diff < 0 ? '− ' : '') + 'Rp ' + fmt(Math.abs(diff));
  db2.parentElement.className = 'diff-box ' + (diff > 0 ? 'pos' : diff < 0 ? 'neg' : '');
});

function nextAddId(rows) {
  let n = 0;
  rows.forEach(r => { const m = /^A(\d+)$/.exec(r._id || ''); if (m) n = Math.max(n, parseInt(m[1], 10)); });
  return 'A' + (n + 1);
}
function addLeaf(key) {
  const month = state.perubahanMonth;
  const rows = getWorking(month);
  const code = key.split('.');
  const newId = nextAddId(rows);
  rows.push({ _id: newId, no: newId, uraian: 'Item baru', rekening: '',
              L1: code[0] || '', L2: code[1] || '', L3: code[2] || '',
              volume: '', satuan: '', tarif: '', jumlah: '0', _added: true });
  saveWorking(month, rows);
  renderRevisi();
  toast('Item baru ditambahkan — silakan isi uraian dan nominalnya.');
}
function delLeaf(id) {
  const month = state.perubahanMonth;
  let rows = getWorking(month);
  rows = rows.filter(r => r._id !== id);
  saveWorking(month, rows);
  renderRevisi();
  toast('Item dihapus.');
}
function delSubtree(key) {
  const month = state.perubahanMonth;
  let rows = getWorking(month);
  const code = key.split('.');
  const before = rows.length;
  rows = rows.filter(r => !isPrefix(code, pathOf(r)));
  if (rows.length === before) { toast('Tidak ada yang dihapus.'); return; }
  saveWorking(month, rows);
  renderRevisi();
  toast('Kelompok beserta item di dalamnya dihapus.');
}
function resetRevisi() {
  const month = state.perubahanMonth;
  delete state.userdata.revisi[month];
  renderRevisi();
  toast('Kembali ke data asli PDF (belum disimpan ke server).');
}
async function saveRevisi() {
  await saveUserdata();
  toast('Revisi anggaran tersimpan.');
}

/* --- REALISASI --- */
function renderRealisasi() {
  const month = state.perubahanMonth;
  const rows = effRows(month);
  const real = state.userdata.realisasi[month] || {};
  const tree = buildTree(rows);
  compute(tree);
  const ang = tree.sum;
  let realTotal = 0;
  rows.forEach(r => { if (isLeafRow(r)) realTotal += parseInt(real[r._id] || 0, 10); });
  const pct = ang ? (realTotal / ang * 100) : 0;
  document.getElementById('reaAnggaran').textContent = 'Rp ' + fmt(ang);
  document.getElementById('reaRealisasi').textContent = 'Rp ' + fmt(realTotal);
  document.getElementById('reaPct').textContent = pct.toFixed(1) + '%';

  function nodeHtml(node, depth) {
    let h = '';
    const cls = depth === 1 ? 'std' : (depth === 2 ? 'sub' : 'subsub');
    const sReal = node.leaves.reduce((a, l) => a + parseInt(real[l._id] || 0, 10), 0) +
                  node.children.reduce((a, c) => a + subReal(c), 0);
    const p = node.sum ? (sReal / node.sum * 100) : 0;
    const barCls = p > 100 ? 'over' : (p > 80 ? 'warn' : '');
    h += `<tr class="${cls}"><td>${esc(node.no || '')}</td><td class="cell-uraian">${esc(node.uraian || '')}</td>
      <td class="num">${fmt(node.sum)}</td><td class="num">${fmt(sReal)}</td>
      <td style="min-width:150px"><div class="progress"><span class="${barCls}" style="width:${Math.min(p,100)}%"></span></div></td>
      <td class="num">${p.toFixed(0)}%</td></tr>`;
    node.children.forEach(c => { h += nodeHtml(c, depth + 1); });
    node.leaves.forEach(l => {
      const lr = parseInt(real[l._id] || 0, 10);
      const lp = money(l.jumlah) ? (lr / money(l.jumlah) * 100) : 0;
      const lbc = lp > 100 ? 'over' : (lp > 80 ? 'warn' : '');
      h += `<tr class="leaf"><td>${esc(l.no)}</td>
        <td class="cell-uraian">${esc(l.uraian)}<br><span class="kode">${esc(l.rekening)}</span></td>
        <td class="num">${fmt(money(l.jumlah))}</td>
        <td><input class="edit-in" type="number" min="0" data-real="${escAttr(l._id)}" value="${lr || ''}" placeholder="0"></td>
        <td><div class="progress"><span class="${lbc}" style="width:${Math.min(lp,100)}%"></span></div></td>
        <td class="num">${lp.toFixed(0)}%</td></tr>`;
    });
    return h;
  }
  function subReal(node) {
    return node.leaves.reduce((a, l) => a + parseInt(real[l._id] || 0, 10), 0) +
           node.children.reduce((a, c) => a + subReal(c), 0);
  }
  let body = '';
  tree.children.forEach(c => { body += nodeHtml(c, 1); });

  document.getElementById('reaTable').innerHTML = `
    <table class="rkas" style="table-layout:fixed">
      <colgroup><col style="width:38px"><col><col style="width:110px"><col style="width:110px"><col style="width:160px"><col style="width:54px"></colgroup>
      <thead><tr><th>No</th><th class="cell-uraian">Uraian</th><th class="num">Anggaran</th><th class="num">Realisasi (Rp)</th><th>Progress</th><th class="num">%</th></tr></thead>
      <tbody>${body}</tbody>
    </table>
    <div class="notice" style="margin-top:12px">Realisasi diinput pada kolom <b>Realisasi (Rp)</b> untuk tiap item belanja, lalu klik <b>Simpan Realisasi</b>.</div>`;
}
document.addEventListener('change', (e) => {
  const t = e.target;
  if (!t.dataset || !t.dataset.real) return;
  const month = state.perubahanMonth;
  if (!state.userdata.realisasi[month]) state.userdata.realisasi[month] = {};
  state.userdata.realisasi[month][t.dataset.real] = parseInt(t.value || '0', 10);
  renderRealisasi();
});
async function saveRealisasi() {
  await saveUserdata();
  toast('Realisasi tersimpan.');
  renderDashboard();
}

/* ------------------------- Catatan SPJ --------------------------- */
function renderSpjChips() {
  document.getElementById('spjChips').innerHTML = MONTHS.map(m =>
    `<button class="${m === state.spjMonth ? 'active' : ''}" onclick="setSpjMonth('${m}')">${m}</button>`).join('');
}
function setSpjMonth(m) { state.spjMonth = m; renderSpjChips(); renderSpj(); }
function renderSpj() {
  const m = state.spjMonth;
  const spj = state.userdata.spj[m] || {};
  document.getElementById('spjNomor').value = spj.nomor || '';
  document.getElementById('spjTanggal').value = spj.tanggal || '';
  document.getElementById('spjUraian').value = spj.uraian || '';
  document.getElementById('spjNilai').value = spj.nilai || '';
  document.getElementById('spjBukti').value = spj.bukti || '';
  const st = document.getElementById('spjStatus');
  const isi = spj.nomor || spj.tanggal || spj.uraian || spj.nilai || spj.bukti;
  if (isi) {
    st.textContent = '✅ SPJ tercatat' + (spj.nilai ? ' · Rp ' + fmt(money(spj.nilai)) : '');
    st.style.background = '#e8f7ef';
    st.style.color = '#1e8449';
  } else {
    st.textContent = 'Belum ada SPJ';
    st.style.background = '#eef3f8';
    st.style.color = '#64748b';
  }
}
function saveSpj() {
  const m = state.spjMonth;
  if (!state.userdata.spj[m]) state.userdata.spj[m] = {};
  state.userdata.spj[m] = {
    nomor: document.getElementById('spjNomor').value.trim(),
    tanggal: document.getElementById('spjTanggal').value.trim(),
    uraian: document.getElementById('spjUraian').value.trim(),
    nilai: document.getElementById('spjNilai').value.trim(),
    bukti: document.getElementById('spjBukti').value.trim(),
  };
  saveUserdata();
  renderSpj();
  toast('Catatan SPJ ' + m + ' tersimpan.');
}

/* ------------------------- persistence --------------------------- */
async function saveUserdata() {
  const payload = {
    revisi: state.userdata.revisi || {},
    realisasi: state.userdata.realisasi || {},
    spj: state.userdata.spj || {},
    ttd: state.userdata.ttd || {},
    school: state.userdata.school || {},
  };
  try {
    const res = await fetch('/api/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (res.ok) { try { localStorage.setItem('arkas_userdata', JSON.stringify(payload)); } catch (e) {} return; }
  } catch (e) { /* offline fallback */ }
  try { localStorage.setItem('arkas_userdata', JSON.stringify(payload)); } catch (e) {}
  toast('Tersimpan lokal (mode offline).');
}

/* ------------------------- printing ------------------------------ */
function setPageOrientation(orientation) {
  let st = document.getElementById('pageOrientation');
  if (!st) {
    st = document.createElement('style');
    st.id = 'pageOrientation';
    document.head.appendChild(st);
  }
  const landscape = orientation === 'landscape';
  st.textContent = '@page { size: A4 ' + (landscape ? 'landscape' : 'portrait') +
                   '; margin: ' + (landscape ? '8mm' : '12mm') + '; }';
}

function startPrint(orientation) {
  setPageOrientation(orientation || 'portrait');
  document.body.classList.add('printing');
  const cleanup = () => {
    document.body.classList.remove('printing');
    const area = document.getElementById('printArea');
    if (area) area.innerHTML = '';
    window.removeEventListener('afterprint', cleanup);
  };
  window.addEventListener('afterprint', cleanup);
  // beri jeda agar @page & konten siap sebelum dialog cetak
  setTimeout(() => window.print(), 60);
}

function printHtml(html, orientation) {
  const area = document.getElementById('printArea');
  if (!area) return;
  area.innerHTML = html;
  startPrint(orientation);
}

function printSection(secId, orientation) {
  const sec = document.getElementById(secId);
  const area = document.getElementById('printArea');
  if (!sec || !area) return;
  // salin isi laporan ke area cetak khusus
  area.innerHTML = sec.innerHTML;
  // sinkronkan nilai input yang belum disimpan agar ikut tercetak
  const srcInputs = sec.querySelectorAll('input, textarea');
  const dstInputs = area.querySelectorAll('input, textarea');
  srcInputs.forEach((el, i) => {
    if (el.type === 'checkbox' || el.type === 'radio') return;
    const d = dstInputs[i];
    if (!d) return;
    if (el.tagName === 'TEXTAREA') d.textContent = el.value;
    else d.setAttribute('value', el.value);
  });
  startPrint(orientation);
}

function printRkas() {
  // RKAS Tahunan (12 kolom) -> landscape; Kertas Kerja per Bulan (9 kolom) -> portrait
  printSection('rkasPrint', state.rkasMode === 'resmi' ? 'landscape' : 'portrait');
}

/* ------------- Cetak / Simpan PDF — ARKAS PERUBAHAN ------------- */
function perubahanReportData(month) {
  const working = getWorking(month);
  const orig = DATA.months[month].rows || [];
  const origByNo = {};
  orig.forEach(r => { origByNo[String(r.no)] = r; });
  const tree = buildTree(working);
  compute(tree);
  const rows = [];
  function walk(node, depth) {
    let nodeBefore = 0;
    const origNode = origByNo[String(node.no)];
    if (origNode) {
      nodeBefore = money(origNode.jumlah);
    } else {
      orig.forEach(r => {
        if (r.rekening && isPrefix(node.code, pathOf(r))) nodeBefore += money(r.jumlah);
      });
    }
    rows.push({ no: node.no || '', uraian: node.uraian || '(kelompok)', depth, isHeader: true,
                before: nodeBefore, after: node.sum });
    node.children.forEach(c => walk(c, depth + 1));
    node.leaves.forEach(l => {
      const ob = origByNo[String(l.no)] ? money(origByNo[String(l.no)].jumlah) : 0;
      rows.push({ no: l.no, uraian: l.uraian, depth: depth + 1, isHeader: false,
                  rekening: l.rekening, volume: l.volume, satuan: l.satuan, tarif: l.tarif,
                  before: ob, after: money(l.jumlah) });
    });
  }
  tree.children.forEach(c => walk(c, 1));
  return { rows, before: money(DATA.months[month].total), after: tree.sum };
}

function buildPerubahanPrintHtml(month) {
  const d = perubahanReportData(month);
  const sd = schoolData();
  let body = '';
  d.rows.forEach(r => {
    if (r.isHeader) {
      const cls = r.depth === 1 ? 'std' : (r.depth === 2 ? 'sub' : 'subsub');
      body += `<tr class="${cls}"><td>${esc(r.no)}</td><td class="cell-uraian"><b>${esc(r.uraian)}</b></td>
        <td></td><td></td><td></td><td></td>
        <td class="num">${fmt(r.before)}</td><td class="num">${fmt(r.after)}</td>
        <td class="num">${fmt(r.after - r.before)}</td></tr>`;
    } else {
      body += `<tr class="leaf"><td>${esc(r.no)}</td><td class="cell-uraian">${esc(r.uraian)}</td>
        <td class="kode">${esc(r.rekening)}</td><td>${esc(r.volume)}</td><td>${esc(r.satuan)}</td>
        <td class="num">${r.tarif ? fmt(money(r.tarif)) : ''}</td>
        <td class="num">${fmt(r.before)}</td><td class="num">${fmt(r.after)}</td>
        <td class="num">${fmt(r.after - r.before)}</td></tr>`;
    }
  });
  return `<div class="form-title">RINCIAN KERTAS KERJA PERUBAHAN</div>
    <div class="form-sub">TAHUN ANGGARAN ${esc(sd.ta || '')} — ${month} ${esc(sd.ta || '')}</div>
    <table class="form-identitas">
      <tr><td style="width:120px">Nama Sekolah</td><td>:</td><td>${esc(sd.nama_sekolah || '')}</td></tr>
      <tr><td>NPSN</td><td>:</td><td>${esc(sd.npsn || '')}</td></tr>
      <tr><td>Kabupaten</td><td>:</td><td>${esc(sd.kabupaten || '')}</td></tr>
      <tr><td>Provinsi</td><td>:</td><td>${esc(sd.provinsi || '')}</td></tr>
      <tr><td>Sumber Dana</td><td>:</td><td>${esc(sd.sumber_dana || '')}</td></tr>
    </table>
    <table class="rkas" style="table-layout:fixed">
      <colgroup>
        <col style="width:34px"><col><col style="width:118px">
        <col style="width:58px"><col style="width:70px"><col style="width:74px">
        <col style="width:90px"><col style="width:90px"><col style="width:90px">
      </colgroup>
      <thead><tr><th>No.</th><th>Uraian</th><th>Kode Rekening</th><th>Volume</th><th>Satuan</th><th class="num">Tarif</th><th class="num">Sebelum (Rp)</th><th class="num">Sesudah (Rp)</th><th class="num">Selisih (Rp)</th></tr></thead>
      <tbody>${body}
        <tr class="total-extra"><td></td><td>JUMLAH SEBELUM</td><td></td><td></td><td></td><td></td><td class="num">${fmt(d.before)}</td><td></td><td></td></tr>
        <tr class="total-extra"><td></td><td>JUMLAH SESUDAH</td><td></td><td></td><td></td><td></td><td></td><td class="num">${fmt(d.after)}</td><td></td></tr>
        <tr class="total"><td></td><td>SELISIH</td><td></td><td></td><td></td><td></td><td></td><td></td><td class="num">${fmt(d.after - d.before)}</td></tr>
      </tbody>
    </table>
    ${signatureBlock()}`;
}

function buildRealisasiPrintHtml(month) {
  const rows = effRows(month);
  const real = state.userdata.realisasi[month] || {};
  const sd = schoolData();
  let body = '';
  let angT = 0, reT = 0;
  rows.forEach(r => {
    if (!isLeafRow(r)) return;
    const ang = money(r.jumlah);
    const re = parseInt(real[r._id] || 0, 10);
    angT += ang;
    reT += re;
    const pct = ang ? (re / ang * 100) : 0;
    body += `<tr class="leaf"><td>${esc(r.no)}</td>
      <td class="cell-uraian">${esc(r.uraian)}<br><span class="kode">${esc(r.rekening)}</span></td>
      <td class="num">${fmt(ang)}</td><td class="num">${fmt(re)}</td><td class="num">${pct.toFixed(1)}%</td></tr>`;
  });
  const pctT = angT ? (reT / angT * 100) : 0;
  return `<div class="form-title">LAPORAN REALISASI ANGGARAN</div>
    <div class="form-sub">TAHUN ANGGARAN ${esc(sd.ta || '')} — ${month} ${esc(sd.ta || '')}</div>
    <table class="form-identitas">
      <tr><td style="width:120px">Nama Sekolah</td><td>:</td><td>${esc(sd.nama_sekolah || '')}</td></tr>
      <tr><td>NPSN</td><td>:</td><td>${esc(sd.npsn || '')}</td></tr>
      <tr><td>Sumber Dana</td><td>:</td><td>${esc(sd.sumber_dana || '')}</td></tr>
    </table>
    <table class="rkas" style="table-layout:fixed">
      <colgroup><col style="width:38px"><col><col style="width:110px"><col style="width:110px"><col style="width:70px"></colgroup>
      <thead><tr><th>No</th><th>Uraian</th><th class="num">Anggaran (Rp)</th><th class="num">Realisasi (Rp)</th><th class="num">%</th></tr></thead>
      <tbody>${body}
        <tr class="total"><td></td><td>JUMLAH</td><td class="num">${fmt(angT)}</td><td class="num">${fmt(reT)}</td><td class="num">${pctT.toFixed(1)}%</td></tr>
      </tbody>
    </table>
    ${signatureBlock()}`;
}

function printPerubahan() {
  const month = state.perubahanMonth;
  if (state.perubahanMode === 'revisi') {
    printHtml(buildPerubahanPrintHtml(month), 'landscape');
  } else {
    printHtml(buildRealisasiPrintHtml(month), 'portrait');
  }
}

/* ---------------------------- init ------------------------------- */
function copyPublicUrl() {
  const el = document.getElementById('publicUrl');
  const url = el ? el.textContent.trim() : (location.origin + '/');
  const done = () => toast('Tautan publik disalin ke clipboard.');
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(url).then(done).catch(() => { fallbackCopy(url); done(); });
  } else {
    fallbackCopy(url);
    done();
  }
}
function fallbackCopy(text) {
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
  } catch (e) {}
}

function renderDashboard() {
  dashCards();
  dashBars();
  renderStandarSummary();
  renderTrenStandar();
}

function init() {
  document.getElementById('pillSchool').textContent = SCHOOL.nama_sekolah || '—';
  document.getElementById('pillMeta').textContent =
    `NPSN ${SCHOOL.npsn || ''} · ${SCHOOL.sumber_dana || ''} · TA ${SCHOOL.ta || ''}`;
  // tautan publik (otomatis mengikuti host tempat aplikasi diakses)
  const pubEl = document.getElementById('publicUrl');
  if (pubEl) pubEl.textContent = location.origin + '/';
  const pubLink = document.getElementById('publicUrlLink');
  if (pubLink) pubLink.setAttribute('href', location.origin + '/');
  // localStorage fallback (only if server has nothing)
  try {
    const ls = localStorage.getItem('arkas_userdata');
    if (ls) {
      const parsed = JSON.parse(ls);
      const serverEmpty = !Object.keys(state.userdata.revisi || {}).length &&
                          !Object.keys(state.userdata.realisasi || {}).length &&
                          !Object.keys(state.userdata.spj || {}).length &&
                          !Object.keys(state.userdata.ttd || {}).length &&
                          !Object.keys(state.userdata.school || {}).length;
      if (serverEmpty) state.userdata = parsed;
    }
  } catch (e) {}
  document.querySelectorAll('nav.tabs button').forEach(b => {
    b.addEventListener('click', () => setTab(b.dataset.tab));
  });
  renderRkasChips();
  renderPerubahanChips();
  renderSpjChips();
  renderDashboard();
  renderRkas();
  renderRkasResmi();
  setRkasMode('resmi');
  renderRevisi();
  renderRealisasi();
  renderSpj();
  renderTtdManager();
  ['kepala', 'bendahara', 'komite'].forEach(role => {
    attachTtd('ttdCanvas-' + role, role);
    drawSaved(role);
  });
}

document.addEventListener('DOMContentLoaded', init);
